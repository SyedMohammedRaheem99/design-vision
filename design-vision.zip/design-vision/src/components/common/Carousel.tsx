'use client';

import { useState } from 'react';
import Image from 'next/image';
import { cn } from '@/lib/utils';
import { ChevronLeft, ChevronRight } from 'lucide-react';

/**
 * Carousel component for displaying testimonials, projects, etc.
 */
interface CarouselProps {
  items: React.ReactNode[];
  autoPlay?: boolean;
  interval?: number;
  className?: string;
}

export default function Carousel({
  items,
  autoPlay = true,
  interval = 5000,
  className,
}: CarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(0);

  const goToPrevious = () => {
    setCurrentIndex((prev) => (prev === 0 ? items.length - 1 : prev - 1));
  };

  const goToNext = () => {
    setCurrentIndex((prev) => (prev === items.length - 1 ? 0 : prev + 1));
  };

  const goToIndex = (index: number) => {
    setCurrentIndex(index);
  };

  // Auto-play functionality
  useState(() => {
    if (!autoPlay) return;
    
    const timer = setInterval(() => {
      goToNext();
    }, interval);

    return () => clearInterval(timer);
  });

  return (
    <div className={cn('relative', className)}>
      {/* Main content */}
      <div className="overflow-hidden">
        <div
          className="flex transition-transform duration-500 ease-out"
          style={{ transform: `translateX(-${currentIndex * 100}%)` }}
        >
          {items.map((item, index) => (
            <div
              key={index}
              className="w-full flex-shrink-0 px-4"
            >
              {item}
            </div>
          ))}
        </div>
      </div>

      {/* Navigation arrows */}
      {items.length > 1 && (
        <>
          <button
            onClick={goToPrevious}
            className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 md:-translate-x-12 w-12 h-12 flex items-center justify-center bg-white shadow-lg border border-neutral-200 hover:bg-neutral-50 transition-colors z-10"
            aria-label="Previous slide"
          >
            <ChevronLeft className="w-5 h-5 text-neutral-700" />
          </button>
          <button
            onClick={goToNext}
            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 md:translate-x-12 w-12 h-12 flex items-center justify-center bg-white shadow-lg border border-neutral-200 hover:bg-neutral-50 transition-colors z-10"
            aria-label="Next slide"
          >
            <ChevronRight className="w-5 h-5 text-neutral-700" />
          </button>
        </>
      )}

      {/* Dots navigation */}
      {items.length > 1 && (
        <div className="flex justify-center gap-2 mt-8">
          {items.map((_, index) => (
            <button
              key={index}
              onClick={() => goToIndex(index)}
              className={cn(
                'w-2 h-2 rounded-full transition-all duration-300',
                index === currentIndex
                  ? 'bg-primary-400 w-8'
                  : 'bg-neutral-300 hover:bg-neutral-400'
              )}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      )}
    </div>
  );
}

/**
 * Simple card slider for project cards
 */
interface CardSliderProps {
  items: React.ReactNode[];
  className?: string;
}

export function CardSlider({ items, className }: CardSliderProps) {
  const [startIndex, setStartIndex] = useState(0);
  const itemsPerView = {
    mobile: 1,
    tablet: 2,
    desktop: 3,
  };

  const visibleItems = items.slice(startIndex, startIndex + itemsPerView.desktop);

  return (
    <div className={cn('relative', className)}>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {visibleItems.map((item, index) => (
          <div key={index} className="animate-fade-in">
            {item}
          </div>
        ))}
      </div>

      {/* Navigation */}
      {items.length > itemsPerView.desktop && (
        <div className="flex justify-center gap-4 mt-8">
          <button
            onClick={() => setStartIndex((prev) => Math.max(0, prev - 1))}
            disabled={startIndex === 0}
            className="w-12 h-12 flex items-center justify-center border border-neutral-300 text-neutral-600 hover:border-primary-400 hover:text-primary-400 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            aria-label="Previous items"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button
            onClick={() => setStartIndex((prev) => Math.min(items.length - itemsPerView.desktop, prev + 1))}
            disabled={startIndex >= items.length - itemsPerView.desktop}
            className="w-12 h-12 flex items-center justify-center border border-neutral-300 text-neutral-600 hover:border-primary-400 hover:text-primary-400 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            aria-label="Next items"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      )}
    </div>
  );
}
