import { ReactNode } from 'react';
import { cn } from '@/lib/utils';

/**
 * Reusable SectionWrapper component
 * Provides consistent spacing and structure for all page sections
 */
interface SectionWrapperProps {
  children: ReactNode;
  className?: string;
  background?: 'white' | 'neutral' | 'primary' | 'dark';
  id?: string;
}

export default function SectionWrapper({
  children,
  className,
  background = 'neutral',
  id,
}: SectionWrapperProps) {
  const backgrounds = {
    white: 'bg-white',
    neutral: 'bg-neutral-50',
    primary: 'bg-primary-400',
    dark: 'bg-neutral-900',
  };

  return (
    <section
      id={id}
      className={cn(
        'py-16 md:py-24 lg:py-32',
        backgrounds[background],
        className
      )}
    >
      {children}
    </section>
  );
}

/**
 * SectionHeader component for consistent section titles
 */
interface SectionHeaderProps {
  title?: string;
  subtitle?: string;
  description?: string;
  align?: 'left' | 'center' | 'right';
  variant?: 'default' | 'white';
}

export function SectionHeader({
  title,
  subtitle,
  description,
  align = 'center',
  variant = 'default',
}: SectionHeaderProps) {
  const alignments = {
    left: 'text-left',
    center: 'text-center',
    right: 'text-right',
  };

  const colors = {
    default: 'text-neutral-900',
    white: 'text-white',
  };

  return (
    <div className={cn('mb-12 md:mb-16', alignments[align])}>
      {subtitle && (
        <span className={cn(
          'block text-sm font-medium tracking-wider uppercase mb-3',
          variant === 'default' ? 'text-primary-400' : 'text-primary-200'
        )}>
          {subtitle}
        </span>
      )}
      {title && (
        <h2 className={cn('font-serif text-3xl md:text-4xl lg:text-5xl font-semibold mb-6', colors[variant])}>
          {title}
        </h2>
      )}
      {description && (
        <p className={cn(
          'text-lg max-w-3xl mx-auto',
          align === 'center' && 'mx-auto',
          variant === 'default' ? 'text-neutral-600' : 'text-neutral-200'
        )}>
          {description}
        </p>
      )}
      <div className={cn(
        'h-0.5 bg-primary-400 mt-6',
        align === 'left' && 'w-16',
        align === 'center' && 'w-16 mx-auto',
        align === 'right' && 'w-16 ml-auto'
      )} />
    </div>
  );
}
