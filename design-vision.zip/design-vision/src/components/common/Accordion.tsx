'use client';

import { useState } from 'react';
import { cn } from '@/lib/utils';

/**
 * Accordion component for FAQ and collapsible content sections
 */
interface AccordionItem {
  id: string;
  question: string;
  answer: string;
}

interface AccordionProps {
  items: AccordionItem[];
  allowMultiple?: boolean;
}

export default function Accordion({ items, allowMultiple = false }: AccordionProps) {
  const [openItems, setOpenItems] = useState<Set<string>>(new Set());

  const toggleItem = (id: string) => {
    setOpenItems((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        if (!allowMultiple) {
          newSet.clear();
        }
        newSet.add(id);
      }
      return newSet;
    });
  };

  return (
    <div className="space-y-4">
      {items.map((item) => {
        const isOpen = openItems.has(item.id);

        return (
          <div
            key={item.id}
            className={cn(
              'border transition-all duration-300',
              isOpen ? 'border-primary-400' : 'border-neutral-200'
            )}
          >
            <button
              onClick={() => toggleItem(item.id)}
              className={cn(
                'w-full px-6 py-5 text-left flex items-center justify-between',
                'hover:bg-neutral-50 transition-colors',
                isOpen && 'bg-neutral-50'
              )}
              aria-expanded={isOpen}
            >
              <span className="font-medium text-lg text-neutral-900">
                {item.question}
              </span>
              <svg
                className={cn(
                  'w-5 h-5 text-neutral-500 transition-transform duration-300',
                  isOpen && 'rotate-180'
                )}
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M19 9l-7 7-7-7"
                />
              </svg>
            </button>
            <div
              className={cn(
                'overflow-hidden transition-all duration-300',
                isOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
              )}
            >
              <div className="px-6 pb-6 pt-2 text-neutral-600 leading-relaxed">
                {item.answer}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
