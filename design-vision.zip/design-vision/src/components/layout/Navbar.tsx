'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Menu, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import { NAV_LINKS, SERVICES_NAV, COMPANY_INFO } from '@/lib/constants';

/**
 * Navbar component - Sticky, responsive navigation with dropdown support
 */
export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isServicesOpen, setIsServicesOpen] = useState(false);
  const pathname = usePathname();

  // Handle scroll effect for navbar styling
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu when route changes
  useEffect(() => {
    setIsMobileMenuOpen(false);
    setIsServicesOpen(false);
  }, [pathname]);

  return (
    <header
      className={cn(
        'fixed top-0 left-0 right-0 z-50 transition-all duration-300',
        isScrolled
          ? 'bg-white/95 backdrop-blur-sm shadow-sm'
          : 'bg-transparent'
      )}
    >
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" aria-label="Main navigation">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-primary-400 flex items-center justify-center">
              <span className="text-white font-serif font-bold text-xl">DV</span>
            </div>
            <div className="hidden sm:block">
              <span className={cn(
                'font-serif font-semibold transition-colors',
                isScrolled ? 'text-neutral-900' : 'text-neutral-900'
              )}>
                Design Vision
              </span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-1">
            {NAV_LINKS.map((link) => (
              <div
                key={link.name}
                className="relative"
                onMouseEnter={() => link.name === 'Services' && setIsServicesOpen(true)}
                onMouseLeave={() => link.name === 'Services' && setIsServicesOpen(false)}
              >
                {link.name === 'Services' ? (
                  <button
                    className={cn(
                      'px-4 py-2 text-sm font-medium transition-colors flex items-center gap-1',
                      isScrolled ? 'text-neutral-700 hover:text-primary-400' : 'text-neutral-700 hover:text-primary-400'
                    )}
                  >
                    Services
                    <svg
                      className={cn('w-4 h-4 transition-transform', isServicesOpen && 'rotate-180')}
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>
                ) : (
                  <Link
                    href={link.href}
                    className={cn(
                      'px-4 py-2 text-sm font-medium transition-colors',
                      pathname === link.href
                        ? 'text-primary-400'
                        : isScrolled
                        ? 'text-neutral-700 hover:text-primary-400'
                        : 'text-neutral-700 hover:text-primary-400'
                    )}
                  >
                    {link.name}
                  </Link>
                )}

                {/* Services Dropdown */}
                {link.name === 'Services' && isServicesOpen && (
                  <div className="absolute top-full left-0 w-64 bg-white shadow-xl border border-neutral-100 py-2 animate-fade-in">
                    {SERVICES_NAV.map((service) => (
                      <Link
                        key={service.href}
                        href={service.href}
                        className="block px-4 py-3 text-sm text-neutral-700 hover:bg-neutral-50 hover:text-primary-400 transition-colors"
                      >
                        {service.name}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* CTA Button & Mobile Menu */}
          <div className="flex items-center space-x-4">
            <Link
              href="/quote"
              className={cn(
                'hidden sm:inline-flex px-5 py-2.5 text-sm font-medium transition-colors',
                isScrolled
                  ? 'bg-primary-400 text-white hover:bg-primary-500'
                  : 'bg-primary-400 text-white hover:bg-primary-500'
              )}
            >
              Get Quote
            </Link>

            {/* Mobile menu button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2 text-neutral-700 hover:text-primary-400 transition-colors"
              aria-label="Toggle menu"
              aria-expanded={isMobileMenuOpen}
            >
              {isMobileMenuOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        <div
          className={cn(
            'lg:hidden overflow-hidden transition-all duration-300',
            isMobileMenuOpen ? 'max-h-[600px] opacity-100' : 'max-h-0 opacity-0'
          )}
        >
          <div className="py-4 space-y-2">
            {NAV_LINKS.map((link) => (
              <div key={link.name}>
                {link.name === 'Services' ? (
                  <div>
                    <button
                      onClick={() => setIsServicesOpen(!isServicesOpen)}
                      className="w-full flex items-center justify-between px-4 py-3 text-sm font-medium text-neutral-700 hover:bg-neutral-50"
                    >
                      Services
                      <svg
                        className={cn('w-4 h-4 transition-transform', isServicesOpen && 'rotate-180')}
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                      </svg>
                    </button>
                    {isServicesOpen && (
                      <div className="bg-neutral-50">
                        {SERVICES_NAV.map((service) => (
                          <Link
                            key={service.href}
                            href={service.href}
                            className="block px-8 py-2 text-sm text-neutral-600 hover:text-primary-400"
                          >
                            {service.name}
                          </Link>
                        ))}
                      </div>
                    )}
                  </div>
                ) : (
                  <Link
                    href={link.href}
                    className={cn(
                      'block px-4 py-3 text-sm font-medium transition-colors',
                      pathname === link.href
                        ? 'text-primary-400 bg-neutral-50'
                        : 'text-neutral-700 hover:bg-neutral-50 hover:text-primary-400'
                    )}
                  >
                    {link.name}
                  </Link>
                )}
              </div>
            ))}
            <div className="pt-4 border-t border-neutral-200">
              <Link
                href="/quote"
                className="block mx-4 px-5 py-3 text-sm font-medium bg-primary-400 text-white text-center hover:bg-primary-500 transition-colors"
              >
                Get Quote
              </Link>
            </div>
          </div>
        </div>
      </nav>
    </header>
  );
}
