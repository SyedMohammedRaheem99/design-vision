import Image from 'next/image';
import { Check, Award, Users, Clock } from 'lucide-react';
import { STATISTICS } from '@/lib/constants';

/**
 * AboutPreview component - Brief company story section
 */
export default function AboutPreview() {
  return (
    <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
      {/* Image */}
      <div className="relative">
        <div className="aspect-[4/5] relative overflow-hidden">
          <Image
            src="https://images.unsplash.com/photo-1616486338812-3dadae4b4f9d?w=800&q=80"
            alt="Our design team at work"
            fill
            className="object-cover"
            sizes="(max-width: 1024px) 100vw, 50vw"
          />
        </div>
        {/* Floating badge */}
        <div className="absolute -bottom-6 -right-6 bg-primary-400 p-6 text-white">
          <div className="text-3xl font-serif font-bold">20+</div>
          <div className="text-sm">Years Experience</div>
        </div>
      </div>

      {/* Content */}
      <div>
        <span className="text-primary-400 text-sm font-medium tracking-wider uppercase mb-4 block">
          About Design Vision
        </span>
        <h2 className="font-serif text-3xl md:text-4xl font-semibold text-neutral-900 mb-6">
          Crafting Spaces That Inspire and Endure
        </h2>
        <p className="text-neutral-600 mb-6 leading-relaxed">
          Founded over two decades ago, Design Vision Constructions & Interiors has established itself as a 
          premier provider of luxury interior design and construction services. Our passion for excellence 
          and attention to detail has earned us the trust of hundreds of homeowners and businesses across 
          the region.
        </p>
        <p className="text-neutral-600 mb-8 leading-relaxed">
          We believe that every space has the potential to become something extraordinary. Our team of 
          experienced designers, architects, and craftsmen work collaboratively to transform visions into 
          reality, creating environments that are both beautiful and functional.
        </p>

        {/* Features */}
        <div className="grid grid-cols-2 gap-4 mb-8">
          {[
            { icon: Check, text: 'Licensed & Insured' },
            { icon: Award, text: 'Award-Winning Designs' },
            { icon: Users, text: 'Expert Team' },
            { icon: Clock, text: 'On-Time Delivery' },
          ].map((feature, index) => (
            <div key={index} className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary-50 flex items-center justify-center">
                <feature.icon className="w-5 h-5 text-primary-400" />
              </div>
              <span className="text-neutral-700 text-sm font-medium">{feature.text}</span>
            </div>
          ))}
        </div>

        <a
          href="/about"
          className="inline-flex items-center text-primary-400 font-medium hover:text-primary-500 transition-colors"
        >
          Learn More About Us
          <svg className="ml-2 w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
          </svg>
        </a>
      </div>
    </div>
  );
}

/**
 * Stats component - Statistics strip
 */
export function Stats() {
  return (
    <div className="bg-neutral-900 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {STATISTICS.map((stat, index) => (
            <div key={index} className="text-center animate-fade-in" style={{ animationDelay: `${index * 100}ms` }}>
              <div className="text-4xl md:text-5xl font-serif font-bold text-primary-400 mb-2">
                {stat.value}
              </div>
              <div className="text-neutral-400 text-sm">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
