import { CheckCircle, Shield, Award, Leaf, Clock, Users } from 'lucide-react';
import { TRUST_BADGES, PROCESS_STEPS } from '@/lib/constants';

/**
 * TrustBadges component - Displays trust indicators and certifications
 */
export default function TrustBadges() {
  const icons = {
    shield: Shield,
    award: Award,
    'check-circle': CheckCircle,
    leaf: Leaf,
  };

  return (
    <div className="bg-neutral-100 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-6 items-center">
          {TRUST_BADGES.map((badge, index) => {
            const Icon = icons[badge.icon as keyof typeof icons] || Shield;
            
            return (
              <div
                key={badge.name}
                className="flex flex-col items-center text-center animate-fade-in"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="w-14 h-14 bg-white rounded-full flex items-center justify-center mb-3 shadow-sm">
                  <Icon className="w-6 h-6 text-primary-400" />
                </div>
                <span className="text-sm font-medium text-neutral-700">{badge.name}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

/**
 * ProcessStrip component - Workflow process visualization
 */
export function ProcessStrip() {
  return (
    <div className="bg-neutral-900 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <span className="text-primary-400 text-sm font-medium tracking-wider uppercase block mb-2">
            Our Process
          </span>
          <h3 className="font-serif text-2xl md:text-3xl font-semibold text-white">
            From Vision to Reality
          </h3>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {PROCESS_STEPS.map((step, index) => (
            <div
              key={step.step}
              className="relative animate-fade-in"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              {/* Connection line */}
              {index < PROCESS_STEPS.length - 1 && (
                <div className="hidden md:block absolute top-6 left-1/2 w-full h-0.5 bg-neutral-700">
                  <div className="absolute right-0 -top-1.5 w-3 h-3 border-t-2 border-r-2 border-neutral-700 transform rotate-45" />
                </div>
              )}

              <div className="text-center">
                <div className="w-12 h-12 bg-primary-400 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-white font-serif font-bold">{step.step}</span>
                </div>
                <h4 className="text-white font-medium mb-2">{step.title}</h4>
                <p className="text-neutral-400 text-xs leading-relaxed">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
