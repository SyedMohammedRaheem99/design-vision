import Link from 'next/link';
import Image from 'next/image';
import { ArrowRight } from 'lucide-react';
import { cn } from '@/lib/utils';

/**
 * HeroSection component - Premium hero with background image and CTA buttons
 */
interface HeroSectionProps {
  title: string;
  subtitle?: string;
  description?: string;
  primaryCTA?: { text: string; href: string };
  secondaryCTA?: { text: string; href: string };
  backgroundImage?: string;
  overlay?: boolean;
  className?: string;
}

export default function HeroSection({
  title,
  subtitle,
  description,
  primaryCTA,
  secondaryCTA,
  backgroundImage = 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=1920&q=80',
  overlay = true,
  className,
}: HeroSectionProps) {
  return (
    <section
      className={cn(
        'relative min-h-screen flex items-center',
        className
      )}
    >
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <Image
          src={backgroundImage}
          alt=""
          fill
          className="object-cover"
          priority
          sizes="100vw"
        />
        {overlay && (
          <div className="absolute inset-0 bg-neutral-900/60" />
        )}
      </div>

      {/* Content */}
      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32">
        <div className="max-w-3xl animate-slide-up">
          {subtitle && (
            <span className="block text-primary-400 text-sm font-medium tracking-wider uppercase mb-4">
              {subtitle}
            </span>
          )}
          <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-semibold text-white leading-tight mb-6">
            {title}
          </h1>
          {description && (
            <p className="text-lg md:text-xl text-neutral-200 mb-10 leading-relaxed max-w-2xl">
              {description}
            </p>
          )}

          {/* CTA Buttons */}
          {(primaryCTA || secondaryCTA) && (
            <div className="flex flex-col sm:flex-row gap-4">
              {primaryCTA && (
                <Link
                  href={primaryCTA.href}
                  className="inline-flex items-center justify-center px-8 py-4 bg-primary-400 text-white font-medium text-sm hover:bg-primary-500 transition-colors"
                >
                  {primaryCTA.text}
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Link>
              )}
              {secondaryCTA && (
                <Link
                  href={secondaryCTA.href}
                  className="inline-flex items-center justify-center px-8 py-4 border-2 border-white text-white font-medium text-sm hover:bg-white hover:text-neutral-900 transition-colors"
                >
                  {secondaryCTA.text}
                </Link>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <svg
          className="w-6 h-6 text-white/70"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M19 14l-7 7m0 0l-7-7m7 7V3"
          />
        </svg>
      </div>
    </section>
  );
}
