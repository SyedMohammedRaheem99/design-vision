import Image from 'next/image';
import { Star } from 'lucide-react';
import { cn } from '@/lib/utils';

/**
 * Testimonials component - Client reviews slider
 */
interface Testimonial {
  id: string;
  name: string;
  role: string;
  project: string;
  content: string;
  rating: number;
  image?: string;
}

const TESTIMONIALS: Testimonial[] = [
  {
    id: '1',
    name: 'Sarah Mitchell',
    role: 'Homeowner',
    project: 'Penthouse Renovation',
    content: 'Working with Design Vision was an absolute pleasure. They transformed our outdated penthouse into a modern sanctuary. Their attention to detail and understanding of our lifestyle needs was exceptional. We could not be happier with the result.',
    rating: 5,
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&q=80',
  },
  {
    id: '2',
    name: 'Michael Chen',
    role: 'CEO',
    project: 'Corporate Office',
    content: 'The team at Design Vision completely reimagined our office space. Productivity has increased, and our employees love the new environment. The project was delivered on time and within budget. Highly recommend!',
    rating: 5,
    image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&q=80',
  },
  {
    id: '3',
    name: 'Jennifer Rodriguez',
    role: 'Restaurant Owner',
    project: 'Restaurant Interior',
    content: 'From concept to completion, Design Vision exceeded our expectations. They created a stunning restaurant interior that has become a destination in itself. Our customers consistently compliment the ambiance.',
    rating: 5,
    image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&q=80',
  },
  {
    id: '4',
    name: 'David Park',
    role: 'Homeowner',
    project: 'Kitchen Remodel',
    content: 'Our new modular kitchen is everything we dreamed of and more. The team was professional, responsive, and truly listened to our needs. The quality of workmanship is outstanding.',
    rating: 5,
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&q=80',
  },
];

export default function Testimonials() {
  return (
    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
      {TESTIMONIALS.map((testimonial, index) => (
        <div
          key={testimonial.id}
          className={cn(
            'bg-white p-8 card',
            'animate-fade-in',
            index >= 3 && 'hidden lg:block'
          )}
          style={{ animationDelay: `${index * 100}ms` }}
        >
          {/* Rating */}
          <div className="flex gap-1 mb-4">
            {Array.from({ length: testimonial.rating }).map((_, i) => (
              <Star key={i} className="w-5 h-5 fill-primary-400 text-primary-400" />
            ))}
          </div>

          {/* Content */}
          <p className="text-neutral-600 mb-6 leading-relaxed">
            "{testimonial.content}"
          </p>

          {/* Author */}
          <div className="flex items-center space-x-4">
            {testimonial.image && (
              <Image
                src={testimonial.image}
                alt={testimonial.name}
                width={48}
                height={48}
                className="rounded-full object-cover"
              />
            )}
            <div>
              <div className="font-medium text-neutral-900">{testimonial.name}</div>
              <div className="text-sm text-neutral-500">{testimonial.role}</div>
              <div className="text-xs text-primary-400">{testimonial.project}</div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

/**
 * TestimonialCard component - Single testimonial display
 */
interface TestimonialCardProps {
  testimonial: Testimonial;
}

export function TestimonialCard({ testimonial }: TestimonialCardProps) {
  return (
    <div className="bg-white p-8 card">
      <div className="flex gap-1 mb-4">
        {Array.from({ length: testimonial.rating }).map((_, i) => (
          <Star key={i} className="w-5 h-5 fill-primary-400 text-primary-400" />
        ))}
      </div>
      <p className="text-neutral-600 mb-6 leading-relaxed">"{testimonial.content}"</p>
      <div className="flex items-center space-x-4">
        {testimonial.image && (
          <Image
            src={testimonial.image}
            alt={testimonial.name}
            width={48}
            height={48}
            className="rounded-full object-cover"
          />
        )}
        <div>
          <div className="font-medium text-neutral-900">{testimonial.name}</div>
          <div className="text-sm text-neutral-500">{testimonial.role}</div>
        </div>
      </div>
    </div>
  );
}
