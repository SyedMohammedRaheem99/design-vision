'use client';

import { useState } from 'react';
import { Input, Textarea, Select } from '../common/Input';
import Button from '../common/Button';
import { Send } from 'lucide-react';

/**
 * QuoteForm component - Request a quote form
 */
export default function QuoteForm() {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    company: '',
    service: '',
    projectType: '',
    budget: '',
    timeline: '',
    propertyType: '',
    squareFootage: '',
    description: '',
    howHeard: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const validate = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.fullName.trim()) {
      newErrors.fullName = 'Full name is required';
    }
    
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email';
    }
    
    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required';
    }
    
    if (!formData.service) {
      newErrors.service = 'Please select a service';
    }
    
    if (!formData.description.trim()) {
      newErrors.description = 'Please provide project details';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validate()) return;
    
    setIsSubmitting(true);
    
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000));
    
    setIsSubmitting(false);
    setSubmitStatus('success');
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: '' }));
    }
  };

  if (submitStatus === 'success') {
    return (
      <div className="bg-green-50 border border-green-200 p-8 text-center">
        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <Send className="w-8 h-8 text-green-600" />
        </div>
        <h3 className="font-serif text-xl font-semibold text-neutral-900 mb-2">
          Quote Request Submitted!
        </h3>
        <p className="text-neutral-600 mb-4">
          Thank you for your interest in our services. A member of our team will contact you 
          within 24-48 hours to discuss your project in detail.
        </p>
        <Button variant="outline" onClick={() => {
          setSubmitStatus('idle');
          setFormData({
            fullName: '', email: '', phone: '', company: '', service: '',
            projectType: '', budget: '', timeline: '', propertyType: '',
            squareFootage: '', description: '', howHeard: '',
          });
        }}>
          Submit Another Request
        </Button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      {/* Personal Information */}
      <div>
        <h3 className="font-serif text-lg font-semibold text-neutral-900 mb-6 pb-2 border-b border-neutral-200">
          Personal Information
        </h3>
        <div className="grid md:grid-cols-2 gap-6">
          <Input
            label="Full Name"
            name="fullName"
            value={formData.fullName}
            onChange={handleChange}
            error={errors.fullName}
            placeholder="John Doe"
            required
          />
          <Input
            label="Email Address"
            name="email"
            type="email"
            value={formData.email}
            onChange={handleChange}
            error={errors.email}
            placeholder="john@example.com"
            required
          />
          <Input
            label="Phone Number"
            name="phone"
            type="tel"
            value={formData.phone}
            onChange={handleChange}
            error={errors.phone}
            placeholder="+1 (555) 123-4567"
            required
          />
          <Input
            label="Company (Optional)"
            name="company"
            value={formData.company}
            onChange={handleChange}
            placeholder="Company Name"
          />
        </div>
      </div>

      {/* Project Details */}
      <div>
        <h3 className="font-serif text-lg font-semibold text-neutral-900 mb-6 pb-2 border-b border-neutral-200">
          Project Details
        </h3>
        <div className="grid md:grid-cols-2 gap-6">
          <Select
            label="Service Required"
            name="service"
            value={formData.service}
            onChange={handleChange}
            error={errors.service}
            options={[
              { value: 'interior-design', label: 'Interior Design' },
              { value: 'residential-construction', label: 'Residential Construction' },
              { value: 'commercial-interiors', label: 'Commercial Interiors' },
              { value: 'modular-kitchen', label: 'Modular Kitchen' },
              { value: 'renovation', label: 'Renovation' },
              { value: 'other', label: 'Other' },
            ]}
            placeholder="Select a service"
            required
          />
          <Select
            label="Property Type"
            name="propertyType"
            value={formData.propertyType}
            onChange={handleChange}
            options={[
              { value: 'single-family', label: 'Single Family Home' },
              { value: 'apartment', label: 'Apartment/Condo' },
              { value: 'townhouse', label: 'Townhouse' },
              { value: 'commercial', label: 'Commercial Space' },
              { value: 'mixed-use', label: 'Mixed Use' },
            ]}
            placeholder="Select property type"
          />
          <Input
            label="Approximate Square Footage"
            name="squareFootage"
            type="text"
            value={formData.squareFootage}
            onChange={handleChange}
            placeholder="e.g., 2,000 sq ft"
          />
          <Select
            label="Estimated Budget"
            name="budget"
            value={formData.budget}
            onChange={handleChange}
            options={[
              { value: 'under-50k', label: 'Under $50,000' },
              { value: '50k-100k', label: '$50,000 - $100,000' },
              { value: '100k-250k', label: '$100,000 - $250,000' },
              { value: '250k-500k', label: '$250,000 - $500,000' },
              { value: '500k-plus', label: '$500,000+' },
              { value: 'not-sure', label: 'Not Sure Yet' },
            ]}
            placeholder="Select budget range"
          />
          <Select
            label="Project Timeline"
            name="timeline"
            value={formData.timeline}
            onChange={handleChange}
            options={[
              { value: 'asap', label: 'ASAP - Ready to start immediately' },
              { value: '1-3-months', label: '1-3 months' },
              { value: '3-6-months', label: '3-6 months' },
              { value: '6-12-months', label: '6-12 months' },
              { value: 'flexible', label: 'Flexible' },
            ]}
            placeholder="Select timeline"
          />
          <Select
            label="How Did You Hear About Us?"
            name="howHeard"
            value={formData.howHeard}
            onChange={handleChange}
            options={[
              { value: 'google', label: 'Google Search' },
              { value: 'referral', label: 'Friend/Colleague Referral' },
              { value: 'social', label: 'Social Media' },
              { value: 'houzz', label: 'Houzz' },
              { value: 'magazine', label: 'Magazine/Publication' },
              { value: 'other', label: 'Other' },
            ]}
            placeholder="Select source"
          />
        </div>
      </div>

      {/* Project Description */}
      <div>
        <h3 className="font-serif text-lg font-semibold text-neutral-900 mb-6 pb-2 border-b border-neutral-200">
          Project Description
        </h3>
        <Textarea
          label="Tell Us About Your Project"
          name="description"
          value={formData.description}
          onChange={handleChange}
          error={errors.description}
          placeholder="Please describe your project, including your goals, any specific requirements, and any relevant details about the space. The more information you provide, the better we can prepare for our initial consultation."
          required
          rows={6}
        />
      </div>

      <div className="pt-4">
        <Button type="submit" size="lg" className="w-full md:w-auto" isLoading={isSubmitting}>
          Submit Quote Request
        </Button>
        <p className="text-sm text-neutral-500 mt-4">
          By submitting this form, you agree to our{' '}
          <a href="/privacy" className="text-primary-400 hover:underline">Privacy Policy</a>
          {' '}and{' '}
          <a href="/terms" className="text-primary-400 hover:underline">Terms & Conditions</a>.
        </p>
      </div>
    </form>
  );
}
