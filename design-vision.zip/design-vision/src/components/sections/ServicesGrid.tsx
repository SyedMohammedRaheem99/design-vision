import Link from 'next/link';
import Image from 'next/image';
import { ArrowRight } from 'lucide-react';
import { cn } from '@/lib/utils';
import { SERVICES_DATA } from '@/lib/data/services';

/**
 * ServicesGrid component - Displays services in an elegant grid layout
 */
export default function ServicesGrid() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
      {SERVICES_DATA.map((service, index) => (
        <Link
          key={service.id}
          href={`/services/${service.slug}`}
          className={cn(
            'group relative overflow-hidden bg-white',
            'animate-fade-in',
            index >= 3 && 'hidden lg:block'
          )}
          style={{ animationDelay: `${index * 100}ms` }}
        >
          {/* Image */}
          <div className="relative h-64 overflow-hidden">
            <Image
              src={service.image}
              alt={service.title}
              fill
              className="object-cover transition-transform duration-500 group-hover:scale-105"
              sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
            />
            <div className="absolute inset-0 bg-neutral-900/40 group-hover:bg-neutral-900/50 transition-colors" />
          </div>

          {/* Content */}
          <div className="absolute inset-0 p-6 flex flex-col justify-end">
            <div className="transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
              <span className="text-primary-400 text-sm font-medium tracking-wider uppercase mb-2 block">
                {service.title}
              </span>
              <h3 className="font-serif text-2xl font-semibold text-white mb-3">
                {service.title}
              </h3>
              <p className="text-neutral-200 text-sm line-clamp-2 mb-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-100">
                {service.shortDescription}
              </p>
              <div className="flex items-center text-primary-400 text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-200">
                Learn More
                <ArrowRight className="ml-2 w-4 h-4 transition-transform group-hover:translate-x-1" />
              </div>
            </div>
          </div>
        </Link>
      ))}
    </div>
  );
}

/**
 * ServiceCard component - Individual service card for compact displays
 */
interface ServiceCardProps {
  service: typeof SERVICES_DATA[0];
  variant?: 'default' | 'horizontal';
}

export function ServiceCard({ service, variant = 'default' }: ServiceCardProps) {
  if (variant === 'horizontal') {
    return (
      <Link
        href={`/services/${service.slug}`}
        className="group flex flex-col md:flex-row bg-white overflow-hidden card-hover"
      >
        <div className="md:w-1/3 relative h-48 md:h-auto overflow-hidden">
          <Image
            src={service.image}
            alt={service.title}
            fill
            className="object-cover transition-transform duration-500 group-hover:scale-105"
            sizes="(max-width: 768px) 100vw, 33vw"
          />
        </div>
        <div className="p-6 md:w-2/3 flex flex-col justify-center">
          <h3 className="font-serif text-xl font-semibold text-neutral-900 mb-2 group-hover:text-primary-400 transition-colors">
            {service.title}
          </h3>
          <p className="text-neutral-600 mb-4">{service.shortDescription}</p>
          <div className="flex items-center text-primary-400 text-sm font-medium">
            Learn More
            <ArrowRight className="ml-2 w-4 h-4 transition-transform group-hover:translate-x-1" />
          </div>
        </div>
      </Link>
    );
  }

  return (
    <Link
      href={`/services/${service.slug}`}
      className="group card p-6 card-hover"
    >
      <div className="w-14 h-14 bg-primary-50 flex items-center justify-center mb-4 group-hover:bg-primary-400 transition-colors">
        <span className="text-primary-400 group-hover:text-white font-serif text-xl font-bold">
          {service.title.charAt(0)}
        </span>
      </div>
      <h3 className="font-serif text-xl font-semibold text-neutral-900 mb-3 group-hover:text-primary-400 transition-colors">
        {service.title}
      </h3>
      <p className="text-neutral-600 mb-4">{service.shortDescription}</p>
      <div className="flex items-center text-primary-400 text-sm font-medium">
        Learn More
        <ArrowRight className="ml-2 w-4 h-4 transition-transform group-hover:translate-x-1" />
      </div>
    </Link>
  );
}
