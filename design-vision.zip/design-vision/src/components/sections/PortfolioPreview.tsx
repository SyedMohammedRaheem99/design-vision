import Link from 'next/link';
import Image from 'next/image';
import { ArrowRight } from 'lucide-react';
import { cn } from '@/lib/utils';
import { getFeaturedProjects } from '@/lib/data/projects';

/**
 * PortfolioPreview component - Displays featured projects in a grid
 */
export default function PortfolioPreview() {
  const projects = getFeaturedProjects();

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {projects.map((project, index) => (
        <Link
          key={project.id}
          href={`/portfolio/${project.slug}`}
          className={cn(
            'group relative overflow-hidden',
            'animate-fade-in',
            index === 0 && 'md:col-span-2 md:aspect-[2/1]',
            index > 0 && 'aspect-[4/3]'
          )}
          style={{ animationDelay: `${index * 100}ms` }}
        >
          {/* Image */}
          <Image
            src={project.thumbnail}
            alt={project.title}
            fill
            className="object-cover transition-transform duration-700 group-hover:scale-110"
            sizes={index === 0 ? '(max-width: 768px) 100vw, 66vw' : '(max-width: 768px) 100vw, 33vw'}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-neutral-900/80 via-neutral-900/20 to-transparent" />

          {/* Content */}
          <div className="absolute inset-0 p-6 flex flex-col justify-end">
            <div className="transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
              <span className="text-primary-400 text-xs font-medium tracking-wider uppercase mb-2 block">
                {project.category}
              </span>
              <h3 className={cn(
                'font-serif font-semibold text-white mb-2',
                index === 0 ? 'text-2xl md:text-3xl' : 'text-xl'
              )}>
                {project.title}
              </h3>
              <p className="text-neutral-300 text-sm line-clamp-2 mb-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-100">
                {project.shortDescription}
              </p>
              <div className="flex items-center text-white text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-200">
                View Project
                <ArrowRight className="ml-2 w-4 h-4 transition-transform group-hover:translate-x-1" />
              </div>
            </div>
          </div>
        </Link>
      ))}
    </div>
  );
}

/**
 * ProjectCard component - Individual project card for portfolio pages
 */
interface ProjectCardProps {
  project: {
    id: string;
    slug: string;
    title: string;
    category: string;
    location: string;
    shortDescription: string;
    thumbnail: string;
  };
  variant?: 'default' | 'featured';
}

export function ProjectCard({ project, variant = 'default' }: ProjectCardProps) {
  return (
    <Link
      href={`/portfolio/${project.slug}`}
      className={cn(
        'group relative overflow-hidden bg-white',
        variant === 'featured' ? 'md:flex' : 'card',
        'card-hover'
      )}
    >
      <div className={cn(
        'relative overflow-hidden',
        variant === 'featured' ? 'md:w-1/2 aspect-[4/3]' : 'aspect-[16/10]'
      )}>
        <Image
          src={project.thumbnail}
          alt={project.title}
          fill
          className="object-cover transition-transform duration-700 group-hover:scale-110"
          sizes={variant === 'featured' ? '(max-width: 768px) 100vw, 50vw' : '(max-width: 768px) 100vw, 33vw'}
        />
      </div>
      <div className={cn(
        'p-6 flex flex-col justify-center',
        variant === 'featured' ? 'md:w-1/2' : ''
      )}>
        <span className="text-primary-400 text-xs font-medium tracking-wider uppercase mb-2 block">
          {project.category}
        </span>
        <h3 className="font-serif text-xl font-semibold text-neutral-900 mb-2 group-hover:text-primary-400 transition-colors">
          {project.title}
        </h3>
        <p className="text-neutral-500 text-sm mb-3">{project.location}</p>
        <p className="text-neutral-600 text-sm line-clamp-2 mb-4">
          {project.shortDescription}
        </p>
        <div className="flex items-center text-primary-400 text-sm font-medium">
          View Details
          <ArrowRight className="ml-2 w-4 h-4 transition-transform group-hover:translate-x-1" />
        </div>
      </div>
    </Link>
  );
}
