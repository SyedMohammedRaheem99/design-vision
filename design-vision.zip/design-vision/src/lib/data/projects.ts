// Mock data for portfolio projects - simulating CMS content for SSG
export interface Project {
  id: string;
  slug: string;
  title: string;
  category: string;
  location: string;
  year: string;
  shortDescription: string;
  fullDescription: string;
  images: string[];
  thumbnail: string;
  features: string[];
  challenge?: string;
  solution?: string;
  client?: string;
  area?: string;
}

export const PROJECTS_DATA: Project[] = [
  {
    id: 'modern-penthouse',
    slug: 'modern-penthouse',
    title: 'Modern Penthouse',
    category: 'Residential',
    location: 'Manhattan, NY',
    year: '2024',
    shortDescription: 'A stunning penthouse renovation featuring contemporary design and panoramic city views.',
    fullDescription: 'This remarkable penthouse renovation in Manhattan showcases the perfect fusion of modern luxury and functional design. The project involved a complete transformation of a 4,500 square foot space, creating an open-concept living area that maximizes the breathtaking city views. The design philosophy centered on clean lines, neutral tones, and high-quality materials that create a sense of sophisticated serenity.',
    images: [
      'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=1200&q=80',
      'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=1200&q=80',
      'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=1200&q=80',
      'https://images.unsplash.com/photo-1600607687644-c7171b42498f?w=1200&q=80',
    ],
    thumbnail: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=600&q=80',
    features: ['Open Concept Design', 'Smart Home Integration', 'Custom Cabinetry', 'Floor-to-Ceiling Windows'],
    challenge: 'Maximize views while maintaining privacy and creating distinct living zones in an open space.',
    solution: 'Strategic placement of glass partitions and built-in storage solutions created functional areas without blocking light.',
    client: 'Private Residence',
    area: '4,500 sq ft',
  },
  {
    id: 'corporate-headquarters',
    slug: 'corporate-headquarters',
    title: 'Corporate Headquarters',
    category: 'Commercial',
    location: 'Brooklyn, NY',
    year: '2023',
    shortDescription: 'A complete office fit-out for a tech companys new headquarters.',
    fullDescription: 'This corporate headquarters project for a leading tech company required a sophisticated approach to modern workspace design. The 25,000 square foot office needed to accommodate 200 employees while promoting collaboration, creativity, and employee well-being. The result is a dynamic workspace that reflects the companys innovative culture while providing functional areas for focused work, meetings, and social interaction.',
    images: [
      'https://images.unsplash.com/photo-1497366811353-6870744d04b2?w=1200&q=80',
      'https://images.unsplash.com/photo-1497366754035-f200968a6e72?w=1200&q=80',
      'https://images.unsplash.com/photo-1497215728101-856f4ea42174?w=1200&q=80',
      'https://images.unsplash.com/photo-1524758631624-e2822e304c36?w=1200&q=80',
    ],
    thumbnail: 'https://images.unsplash.com/photo-1497366811353-6870744d04b2?w=600&q=80',
    features: ['Open Plan Office', 'Meeting Rooms', 'Break Areas', 'Reception'],
    challenge: 'Create a flexible workspace that can adapt to changing team sizes and work styles.',
    solution: 'Modular furniture systems and versatile meeting spaces that can be reconfigured as needed.',
    client: 'Tech Innovations Inc.',
    area: '25,000 sq ft',
  },
  {
    id: 'luxury-restaurant',
    slug: 'luxury-restaurant',
    title: 'Luxury Restaurant',
    category: 'Hospitality',
    location: 'Midtown, NY',
    year: '2024',
    shortDescription: 'An elegant restaurant design combining classic sophistication with modern elements.',
    fullDescription: 'This luxury restaurant project transformed a historic space into a contemporary dining destination. The design honors the building\'s heritage while introducing modern elements that create a fresh, inviting atmosphere. The 3,500 square foot space includes a main dining room, private dining area, and an intimate bar lounge, each with its own distinct character while maintaining a cohesive design language.',
    images: [
      'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=1200&q=80',
      'https://images.unsplash.com/photo-1552566626-52f8b828add9?w=1200&q=80',
      'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=1200&q=80',
      'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=1200&q=80',
    ],
    thumbnail: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=600&q=80',
    features: ['Main Dining', 'Private Dining', 'Bar Lounge', 'Outdoor Terrace'],
    challenge: 'Balance historic preservation with modern design while creating an intimate atmosphere.',
    solution: 'Carefully restored original details paired with contemporary lighting and furniture.',
    client: 'Epicurean Group',
    area: '3,500 sq ft',
  },
  {
    id: 'contemporary-kitchen',
    slug: 'contemporary-kitchen',
    title: 'Contemporary Kitchen',
    category: 'Modular Kitchen',
    location: 'Greenwich, CT',
    year: '2023',
    shortDescription: 'A sleek modular kitchen designed for a modern family home.',
    fullDescription: 'This contemporary kitchen project showcases the perfect blend of form and function. The modular design maximizes storage and workspace while creating a stunning visual statement. The kitchen features custom cabinetry, a large island with seating, and premium appliances, all coordinated in a cohesive color scheme that flows seamlessly into the adjacent living and dining areas.',
    images: [
      'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=1200&q=80',
      'https://images.unsplash.com/photo-1556909172-54557c7e4fb7?w=1200&q=80',
      'https://images.unsplash.com/photo-1556909212-d5b604d0c90d?w=1200&q=80',
      'https://images.unsplash.com/photo-1556909190-eccf4a8bf97a?w=1200&q=80',
    ],
    thumbnail: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=600&q=80',
    features: ['L-Shaped Layout', 'Kitchen Island', 'Pantry Storage', 'Premium Appliances'],
    challenge: 'Create a kitchen that serves as both a functional workspace and a social hub.',
    solution: 'Open layout with large island that connects the kitchen to living areas.',
    client: 'Private Residence',
    area: '400 sq ft',
  },
  {
    id: 'brownstone-renovation',
    slug: 'brownstone-renovation',
    title: 'Brownstone Renovation',
    category: 'Renovation',
    location: 'Park Slope, NY',
    year: '2023',
    shortDescription: 'A complete renovation of a historic brownstone home.',
    fullDescription: 'This comprehensive brownstone renovation preserved the historic character of a 19th-century home while bringing it into the 21st century. The project included structural repairs, updated mechanical systems, and a complete interior redesign that honors the building\'s original details while providing modern amenities. The result is a timeless home that seamlessly blends old-world charm with contemporary comfort.',
    images: [
      'https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?w=1200&q=80',
      'https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?w=1200&q=80',
      'https://images.unsplash.com/photo-1600585154526-990dced4db0d?w=1200&q=80',
      'https://images.unsplash.com/photo-1600573472550-8090b5e0745e?w=1200&q=80',
    ],
    thumbnail: 'https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?w=600&q=80',
    features: ['Historic Preservation', 'Modern Amenities', 'Open Layout', 'Garden Level'],
    challenge: 'Preserve historic character while creating modern, functional living spaces.',
    solution: 'Careful restoration of original details combined with discreet modern additions.',
    client: 'Private Residence',
    area: '5,200 sq ft',
  },
  {
    id: 'spa-wellness-center',
    slug: 'spa-wellness-center',
    title: 'Spa & Wellness Center',
    category: 'Commercial',
    location: 'SoHo, NY',
    year: '2024',
    shortDescription: 'A tranquil spa design creating a peaceful retreat in the city.',
    fullDescription: 'This spa and wellness center project created a serene urban retreat focused on relaxation and rejuvenation. The design uses natural materials, soft lighting, and calming colors to establish an immediate sense of tranquility. The facility includes treatment rooms, a relaxation lounge, meditation spaces, and a Himalayan salt sauna, all designed to provide a complete wellness experience.',
    images: [
      'https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=1200&q=80',
      'https://images.unsplash.com/photo-1600334129128-685c54305020?w=1200&q=80',
      'https://images.unsplash.com/photo-1540555700478-4be289fbecef?w=1200&q=80',
      'https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?w=1200&q=80',
    ],
    thumbnail: 'https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=600&q=80',
    features: ['Treatment Rooms', 'Sauna', 'Relaxation Lounge', 'Reception'],
    challenge: 'Create a sense of calm in a busy urban environment.',
    solution: 'Soundproofing, natural materials, and strategic lighting create an oasis of tranquility.',
    client: 'Wellness Collective',
    area: '6,500 sq ft',
  },
];

// Helper function to get project by slug
export function getProjectBySlug(slug: string): Project | undefined {
  return PROJECTS_DATA.find((project) => project.slug === slug);
}

// Helper function to get all project slugs for SSG
export function getAllProjectSlugs(): string[] {
  return PROJECTS_DATA.map((project) => project.slug);
}

// Get projects by category
export function getProjectsByCategory(category: string): Project[] {
  return PROJECTS_DATA.filter((project) => project.category === category);
}

// Get featured projects for homepage
export function getFeaturedProjects(): Project[] {
  return PROJECTS_DATA.slice(0, 4);
}
