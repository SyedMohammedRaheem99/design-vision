// Mock data for services - simulating CMS content for SSG
export interface Service {
  id: string;
  slug: string;
  title: string;
  shortDescription: string;
  fullDescription: string;
  benefits: string[];
  process: {
    title: string;
    description: string;
  }[];
  image: string;
  icon: string;
  features: string[];
}

export const SERVICES_DATA: Service[] = [
  {
    id: 'interior-design',
    slug: 'interior-design',
    title: 'Interior Design',
    shortDescription: 'Transform your space with our expert interior design services tailored to your lifestyle and preferences.',
    fullDescription: 'Our interior design service brings together aesthetics, functionality, and your personal style to create spaces that truly reflect who you are. From concept development to final installation, our team of experienced designers works closely with you to understand your vision and translate it into reality. We pay attention to every detail, from color palettes and furniture selection to lighting design and spatial planning, ensuring a cohesive and harmonious result that exceeds your expectations.',
    benefits: [
      'Personalized design solutions tailored to your lifestyle',
      'Expert guidance on color schemes, materials, and finishes',
      'Access to premium furniture and decor collections',
      '3D renderings to visualize your space before implementation',
      'Project management from concept to completion',
      'Budget-friendly options without compromising quality',
    ],
    process: [
      {
        title: 'Initial Consultation',
        description: 'We meet to discuss your vision, requirements, lifestyle needs, and budget constraints.',
      },
      {
        title: 'Concept Development',
        description: 'Our designers create mood boards, space plans, and preliminary design concepts for your review.',
      },
      {
        title: 'Design Refinement',
        description: 'We refine the selected concept based on your feedback, selecting specific materials, furniture, and finishes.',
      },
      {
        title: 'Implementation',
        description: 'We coordinate with contractors and vendors to execute the design plan with precision.',
      },
      {
        title: 'Final Styling',
        description: 'Our team handles all the details from furniture placement to accessory styling for the perfect finish.',
      },
    ],
    image: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?w=800&q=80',
    icon: 'palette',
    features: [
      'Residential & Commercial Design',
      'Space Planning & Layout',
      'Color Consultation',
      'Furniture Selection',
      'Lighting Design',
      'Art & Accessory Curation',
    ],
  },
  {
    id: 'residential',
    slug: 'residential',
    title: 'Residential Construction',
    shortDescription: 'Build your dream home with our comprehensive residential construction services.',
    fullDescription: 'Our residential construction service delivers exceptional quality homes built to last. From custom single-family residences to multi-unit developments, we bring decades of expertise to every project. Our process begins with understanding your vision and ends with a home that exceeds your expectations in every way. We use only the highest quality materials and work with skilled tradespeople who share our commitment to excellence.',
    benefits: [
      'Custom homes tailored to your specifications',
      'Energy-efficient construction practices',
      'Transparent pricing and project timeline',
      'Quality craftsmanship by skilled professionals',
      'Compliance with all building codes and regulations',
      'Warranty and post-construction support',
    ],
    process: [
      {
        title: 'Site Selection & Analysis',
        description: 'We help evaluate potential sites and assess feasibility for your construction project.',
      },
      {
        title: 'Design & Planning',
        description: 'Our architects create detailed plans and obtain necessary permits before construction begins.',
      },
      {
        title: 'Foundation & Structure',
        description: 'Our skilled team completes the foundation and structural work with precision and care.',
      },
      {
        title: 'Systems Installation',
        description: 'We install plumbing, electrical, HVAC, and other essential building systems.',
      },
      {
        title: 'Finishing & Handover',
        description: 'Final inspections, punch list completion, and your dream home is ready.',
      },
    ],
    image: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80',
    icon: 'home',
    features: [
      'Custom Home Building',
      'Home Additions',
      'Foundation Work',
      'Structural Engineering',
      'Energy-Efficient Building',
      'Smart Home Integration',
    ],
  },
  {
    id: 'commercial',
    slug: 'commercial',
    title: 'Commercial Interiors',
    shortDescription: 'Create productive, inspiring workspaces with our commercial interior design expertise.',
    fullDescription: 'Our commercial interior design service focuses on creating spaces that enhance productivity, reflect your brand identity, and provide exceptional experiences for employees and customers alike. We understand that commercial spaces have unique requirements including ergonomic considerations, accessibility compliance, and brand integration. From corporate offices to retail environments and hospitality spaces, we deliver solutions that work as hard as you do.',
    benefits: [
      'Spaces designed for productivity and employee well-being',
      'Brand-aligned interior concepts',
      'Compliance with commercial building regulations',
      'Flexible design for evolving business needs',
      'Project completion on time and within budget',
      'Minimal disruption to business operations',
    ],
    process: [
      {
        title: 'Business Analysis',
        description: 'We analyze your business operations, brand identity, and space requirements.',
      },
      {
        title: 'Concept & Branding',
        description: 'Design concepts that align with your brand and support business objectives.',
      },
      {
        title: 'Space Planning',
        description: 'Optimized layouts for workflows, collaboration, and customer interactions.',
      },
      {
        title: 'Construction & Installation',
        description: 'Professional installation with minimal impact on your business operations.',
      },
      {
        title: 'Final Reveal & Support',
        description: 'Comprehensive handover and ongoing support for your new space.',
      },
    ],
    image: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=800&q=80',
    icon: 'building',
    features: [
      'Office Design & Fit-outs',
      'Retail Space Design',
      'Restaurant & Hospitality',
      'Medical & Dental Offices',
      'Educational Facilities',
      'Multi-use Complexes',
    ],
  },
  {
    id: 'kitchen',
    slug: 'kitchen',
    title: 'Modular Kitchen',
    shortDescription: 'Discover the perfect blend of style and functionality with our premium modular kitchen solutions.',
    fullDescription: 'Our modular kitchen service offers the ultimate in modern kitchen design, combining sleek aesthetics with practical functionality. Modular kitchens provide flexibility, efficient space utilization, and customization options that traditional kitchens simply cannot match. We work with leading manufacturers to bring you high-quality cabinetry, countertops, and accessories that transform your kitchen into the heart of your home.',
    benefits: [
      'Customizable layouts to fit any space',
      'High-quality materials and hardware',
      'Optimized storage solutions',
      'Easy installation and maintenance',
      'Contemporary aesthetics',
      'Increased home value',
    ],
    process: [
      {
        title: 'Consultation & Measurement',
        description: 'Detailed consultation to understand your cooking habits and space requirements.',
      },
      {
        title: 'Design & Layout',
        description: 'We create modular layouts that maximize functionality and aesthetic appeal.',
      },
      {
        title: 'Material Selection',
        description: 'Choose from our curated selection of cabinets, countertops, and finishes.',
      },
      {
        title: 'Manufacturing',
        description: 'Your custom kitchen is precision-manufactured to exact specifications.',
      },
      {
        title: 'Installation & Finishing',
        description: 'Professional installation with attention to every detail.',
      },
    ],
    image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800&q=80',
    icon: 'utensils',
    features: [
      'L-shaped Kitchens',
      'U-shaped Kitchens',
      'Parallel Kitchens',
      'Island Kitchens',
      'Open Concept Kitchens',
      'Custom Cabinetry',
    ],
  },
  {
    id: 'renovation',
    slug: 'renovation',
    title: 'Renovation',
    shortDescription: 'Transform existing spaces with our expert renovation services.',
    fullDescription: 'Our renovation service breathes new life into existing spaces, whether you want to update a single room or undertake a complete home transformation. We handle everything from kitchen and bathroom remodels to whole-home renovations, working within your budget and timeline. Our team manages every aspect of the renovation process, minimizing stress and delivering exceptional results that enhance both the beauty and value of your property.',
    benefits: [
      'Increased property value and appeal',
      'Updated functionality for modern living',
      'Energy efficiency improvements',
      'Minimal disruption to daily life',
      'One-stop project management',
      'Quality assurance and warranties',
    ],
    process: [
      {
        title: 'Assessment & Planning',
        description: 'Comprehensive evaluation of existing conditions and renovation scope.',
      },
      {
        title: 'Design Consultation',
        description: 'Collaborative design process to realize your renovation vision.',
      },
      {
        title: 'Permits & Preparation',
        description: 'We handle all necessary permits and pre-construction preparation.',
      },
      {
        title: 'Construction',
        description: 'Skilled craftsmen execute the renovation with attention to detail.',
      },
      {
        title: 'Final Walkthrough',
        description: 'Quality inspection and your renovated space is ready to enjoy.',
      },
    ],
    image: 'https://images.unsplash.com/photo-1484154218962-a197022b5858?w=800&q=80',
    icon: 'hammer',
    features: [
      'Kitchen Remodeling',
      'Bathroom Renovation',
      'Whole Home Renovation',
      'Room Additions',
      'Basement Finishing',
      'Exterior Updates',
    ],
  },
];

// Helper function to get service by slug
export function getServiceBySlug(slug: string): Service | undefined {
  return SERVICES_DATA.find((service) => service.slug === slug);
}

// Helper function to get all service slugs for SSG
export function getAllServiceSlugs(): string[] {
  return SERVICES_DATA.map((service) => service.slug);
}

// Service categories for filtering and display
export const SERVICE_CATEGORIES = [
  {
    id: 'interior-design',
    name: 'Interior Design',
    slug: 'interior-design',
    description: 'Complete interior design solutions for residential and commercial spaces',
    icon: 'palette',
    color: 'primary',
  },
  {
    id: 'residential',
    name: 'Residential Construction',
    slug: 'residential',
    description: 'Quality home construction from foundation to finishing',
    icon: 'home',
    color: 'blue',
  },
  {
    id: 'commercial',
    name: 'Commercial Interiors',
    slug: 'commercial',
    description: 'Professional interiors for offices, retail, and hospitality',
    icon: 'building',
    color: 'green',
  },
  {
    id: 'kitchen',
    name: 'Modular Kitchen',
    slug: 'kitchen',
    description: 'Modern, functional kitchen designs and installations',
    icon: 'utensils',
    color: 'orange',
  },
  {
    id: 'renovation',
    name: 'Renovation',
    slug: 'renovation',
    description: 'Transform existing spaces with expert renovation services',
    icon: 'hammer',
    color: 'purple',
  },
];

// Helper function to get category by slug
export function getCategoryBySlug(slug: string) {
  return SERVICE_CATEGORIES.find((category) => category.slug === slug);
}

// Get all category slugs
export function getAllCategorySlugs(): string[] {
  return SERVICE_CATEGORIES.map((category) => category.slug);
}
