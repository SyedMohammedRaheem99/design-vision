/**
 * Site-wide constants including navigation links, company information, and static data
 * Centralized configuration for easy updates
 */

// Company Information
export const COMPANY_INFO = {
  name: 'Design Vision Constructions & Interiors',
  shortName: 'Design Vision',
  tagline: 'Crafting Spaces That Inspire',
  description: 'Premium interior design and construction company dedicated to transforming spaces into timeless masterpieces.',
  email: 'info@designvision.com',
  phone: '+1 (555) 123-4567',
  address: '1234 Design Avenue, Suite 100, New York, NY 10001',
  hours: 'Mon - Fri: 9:00 AM - 6:00 PM\nSat: 10:00 AM - 4:00 PM\nSun: Closed',
  social: {
    facebook: 'https://facebook.com/designvision',
    instagram: 'https://instagram.com/designvision',
    linkedin: 'https://linkedin.com/company/designvision',
    pinterest: 'https://pinterest.com/designvision',
  },
};

// Navigation Links
export const NAV_LINKS = [
  { name: 'Home', href: '/' },
  { name: 'About', href: '/about' },
  { name: 'Services', href: '/services' },
  { name: 'Portfolio', href: '/portfolio' },
  { name: 'Blog', href: '/blog' },
  { name: 'Testimonials', href: '/testimonials' },
  { name: 'FAQ', href: '/faq' },
  { name: 'Contact', href: '/contact' },
];

// Services Navigation (for services dropdown and listing)
export const SERVICES_NAV = [
  {
    name: 'Interior Design',
    href: '/services/interior-design',
    description: 'Complete interior design solutions for residential and commercial spaces',
    icon: 'palette',
  },
  {
    name: 'Residential Construction',
    href: '/services/residential',
    description: 'Quality home construction from foundation to finishing',
    icon: 'home',
  },
  {
    name: 'Commercial Interiors',
    href: '/services/commercial',
    description: 'Professional interiors for offices, retail, and hospitality',
    icon: 'building',
  },
  {
    name: 'Modular Kitchen',
    href: '/services/kitchen',
    description: 'Modern, functional kitchen designs and installations',
    icon: 'utensils',
  },
  {
    name: 'Renovation',
    href: '/services/renovation',
    description: 'Transform existing spaces with expert renovation services',
    icon: 'hammer',
  },
];

// Footer Links
export const FOOTER_LINKS = {
  company: [
    { name: 'About Us', href: '/about' },
    { name: 'Our Team', href: '/about#team' },
    { name: 'Careers', href: '/careers' },
    { name: 'Press', href: '/press' },
  ],
  services: [
    { name: 'Interior Design', href: '/services/interior-design' },
    { name: 'Residential Construction', href: '/services/residential' },
    { name: 'Commercial Interiors', href: '/services/commercial' },
    { name: 'Modular Kitchen', href: '/services/kitchen' },
    { name: 'Renovation', href: '/services/renovation' },
  ],
  support: [
    { name: 'Contact Us', href: '/contact' },
    { name: 'Request Quote', href: '/quote' },
    { name: 'FAQ', href: '/faq' },
    { name: 'Testimonials', href: '/testimonials' },
  ],
  legal: [
    { name: 'Privacy Policy', href: '/privacy' },
    { name: 'Terms & Conditions', href: '/terms' },
    { name: 'Cookie Policy', href: '/cookies' },
  ],
};

// Trust Badges / Certifications
export const TRUST_BADGES = [
  { name: 'Licensed & Insured', icon: 'shield' },
  { name: '20+ Years Experience', icon: 'award' },
  { name: '500+ Projects Completed', icon: 'check-circle' },
  { name: '5-Star Rating', icon: 'star' },
  { name: 'Eco-Friendly Practices', icon: 'leaf' },
];

// Process Steps
export const PROCESS_STEPS = [
  {
    step: '01',
    title: 'Consultation',
    description: 'We discuss your vision, requirements, and budget to understand your needs.',
  },
  {
    step: '02',
    title: 'Design',
    description: 'Our team creates detailed plans, 3D renderings, and material selections.',
  },
  {
    step: '03',
    title: 'Planning',
    description: 'We develop a comprehensive project timeline and coordinate all resources.',
  },
  {
    step: '04',
    title: 'Execution',
    description: 'Our skilled craftsmen bring your vision to life with precision and care.',
  },
  {
    step: '05',
    title: 'Delivery',
    description: 'Final walkthrough, quality check, and your dream space is ready.',
  },
];

// Homepage Stats
export const STATISTICS = [
  { value: '20+', label: 'Years Experience' },
  { value: '500+', label: 'Projects Completed' },
  { value: '98%', label: 'Client Satisfaction' },
  { value: '50+', label: 'Design Awards' },
];
