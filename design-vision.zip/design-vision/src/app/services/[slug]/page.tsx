import type { Metadata } from 'next';
import Link from 'next/link';
import Image from 'next/image';
import { CheckCircle, ArrowRight } from 'lucide-react';
import SectionWrapper from '@/components/common/SectionWrapper';
import { SectionHeader } from '@/components/common/SectionWrapper';
import { getServiceBySlug, SERVICES_DATA } from '@/lib/data/services';

/**
 * Generate static params for all service pages (SSG)
 */
export async function generateStaticParams() {
  return SERVICES_DATA.map((service) => ({
    slug: service.slug,
  }));
}

/**
 * Generate metadata for SEO
 */
export async function generateMetadata({ params }: { params: { slug: string } }) {
  const service = getServiceBySlug(params.slug);
  
  if (!service) {
    return {
      title: 'Service Not Found',
    };
  }

  return {
    title: service.title,
    description: service.shortDescription,
  };
}

/**
 * Individual service page template
 */
export default function ServicePage({ params }: { params: { slug: string } }) {
  const service = getServiceBySlug(params.slug);

  if (!service) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="font-serif text-3xl font-semibold text-neutral-900 mb-4">
            Service Not Found
          </h1>
          <p className="text-neutral-600 mb-6">
            The service you're looking for doesn't exist.
          </p>
          <Link
            href="/services"
            className="inline-flex items-center text-primary-400 font-medium hover:text-primary-500"
          >
            Back to Services
            <ArrowRight className="ml-2 w-4 h-4" />
          </Link>
        </div>
      </div>
    );
  }

  return (
    <>
      {/* Page Header with Hero Image */}
      <section className="relative pt-32 pb-16">
        <div className="absolute inset-0 z-0">
          <Image
            src={service.image}
            alt=""
            fill
            className="object-cover"
            priority
            sizes="100vw"
          />
          <div className="absolute inset-0 bg-neutral-900/70" />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex items-center space-x-2 text-sm text-neutral-300 mb-6">
            <Link href="/" className="hover:text-white transition-colors">Home</Link>
            <span>/</span>
            <Link href="/services" className="hover:text-white transition-colors">Services</Link>
            <span>/</span>
            <span className="text-primary-400">{service.title}</span>
          </nav>
          <h1 className="font-serif text-4xl md:text-5xl font-semibold text-white mb-4">
            {service.title}
          </h1>
          <p className="text-xl text-neutral-200 max-w-2xl">
            {service.shortDescription}
          </p>
        </div>
      </section>

      {/* Overview Section */}
      <SectionWrapper background="white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-start">
            <div>
              <span className="text-primary-400 text-sm font-medium tracking-wider uppercase mb-4 block">
                Overview
              </span>
              <h2 className="font-serif text-3xl md:text-4xl font-semibold text-neutral-900 mb-6">
                Expert {service.title} Services
              </h2>
              <p className="text-neutral-600 mb-6 leading-relaxed">
                {service.fullDescription}
              </p>
              <p className="text-neutral-600 leading-relaxed">
                Whether you're looking to transform a single room or undertake a complete 
                renovation, our team has the expertise and resources to deliver exceptional 
                results that exceed your expectations.
              </p>
            </div>

            <div>
              <div className="bg-neutral-50 p-8">
                <h3 className="font-serif text-xl font-semibold text-neutral-900 mb-6">
                  Key Features
                </h3>
                <ul className="space-y-4">
                  {service.features.map((feature, index) => (
                    <li key={index} className="flex items-start space-x-3">
                      <CheckCircle className="w-5 h-5 text-primary-400 flex-shrink-0 mt-0.5" />
                      <span className="text-neutral-700">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </SectionWrapper>

      {/* Benefits Section */}
      <SectionWrapper background="neutral">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader
            subtitle="Benefits"
            title={`Why Choose Our ${service.title} Services`}
            description="We deliver exceptional value through our commitment to quality and client satisfaction."
            align="center"
          />

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {service.benefits.map((benefit, index) => (
              <div
                key={index}
                className="bg-white p-6 card animate-fade-in"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="w-12 h-12 bg-primary-50 flex items-center justify-center mb-4">
                  <CheckCircle className="w-6 h-6 text-primary-400" />
                </div>
                <p className="text-neutral-700">{benefit}</p>
              </div>
            ))}
          </div>
        </div>
      </SectionWrapper>

      {/* Process Section */}
      <SectionWrapper background="white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader
            subtitle="Our Process"
            title="How We Work"
            description="Our proven process ensures a smooth journey from concept to completion."
            align="center"
          />

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {service.process.map((step, index) => (
              <div
                key={index}
                className="relative animate-fade-in"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                {index < service.process.length - 1 && (
                  <div className="hidden lg:block absolute top-12 left-1/2 w-full h-0.5 bg-neutral-200">
                    <div className="absolute right-0 -top-1.5 w-3 h-3 border-t-2 border-r-2 border-neutral-200 transform rotate-45" />
                  </div>
                )}
                <div className="bg-white p-6 border border-neutral-200 text-center relative z-10">
                  <div className="w-12 h-12 bg-primary-400 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-white font-serif font-bold">{index + 1}</span>
                  </div>
                  <h3 className="font-serif text-lg font-semibold text-neutral-900 mb-3">
                    {step.title}
                  </h3>
                  <p className="text-neutral-600 text-sm">{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </SectionWrapper>

      {/* CTA Section */}
      <SectionWrapper background="neutral">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-serif text-3xl md:text-4xl font-semibold text-neutral-900 mb-6">
            Ready to Get Started?
          </h2>
          <p className="text-neutral-600 mb-8 text-lg">
            Contact us today for a free consultation and let's discuss how we can bring your vision to life.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/quote"
              className="inline-flex items-center justify-center px-8 py-4 bg-primary-400 text-white font-medium hover:bg-primary-500 transition-colors"
            >
              Request a Quote
            </Link>
            <Link
              href="/contact"
              className="inline-flex items-center justify-center px-8 py-4 border-2 border-neutral-900 text-neutral-900 font-medium hover:bg-neutral-900 hover:text-white transition-colors"
            >
              Contact Us
            </Link>
          </div>
        </div>
      </SectionWrapper>

      {/* Other Services */}
      <SectionWrapper background="white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader
            subtitle="Explore More"
            title="Other Services"
            description="Discover our full range of interior design and construction services."
            align="center"
          />

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {SERVICES_DATA.filter((s) => s.id !== service.id).map((otherService) => (
              <Link
                key={otherService.id}
                href={`/services/${otherService.slug}`}
                className="group card p-6 card-hover"
              >
                <h3 className="font-serif text-lg font-semibold text-neutral-900 mb-2 group-hover:text-primary-400 transition-colors">
                  {otherService.title}
                </h3>
                <p className="text-neutral-600 text-sm mb-4">{otherService.shortDescription}</p>
                <div className="flex items-center text-primary-400 text-sm font-medium">
                  Learn More
                  <ArrowRight className="ml-2 w-4 h-4 transition-transform group-hover:translate-x-1" />
                </div>
              </Link>
            ))}
          </div>
        </div>
      </SectionWrapper>
    </>
  );
}
