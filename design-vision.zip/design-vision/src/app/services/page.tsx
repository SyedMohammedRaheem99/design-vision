import type { Metadata } from 'next';
import Link from 'next/link';
import Image from 'next/image';
import { ArrowRight } from 'lucide-react';
import SectionWrapper from '@/components/common/SectionWrapper';
import { SectionHeader } from '@/components/common/SectionWrapper';
import { SERVICES_DATA } from '@/lib/data/services';

/**
 * Services parent page metadata
 */
export const metadata: Metadata = {
  title: 'Services',
  description: 'Explore our comprehensive interior design and construction services including residential, commercial, modular kitchens, and renovation.',
};

/**
 * Service detail page content
 */
export default function ServicesPage() {
  return (
    <>
      {/* Page Header */}
      <section className="pt-32 pb-16 bg-neutral-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="font-serif text-4xl md:text-5xl font-semibold text-white mb-4">
            Our Services
          </h1>
          <nav className="flex items-center space-x-2 text-sm text-neutral-400">
            <Link href="/" className="hover:text-white transition-colors">Home</Link>
            <span>/</span>
            <span className="text-primary-400">Services</span>
          </nav>
        </div>
      </section>

      {/* Services Overview */}
      <SectionWrapper background="white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-primary-400 text-sm font-medium tracking-wider uppercase mb-4 block">
              What We Offer
            </span>
            <h2 className="font-serif text-3xl md:text-4xl font-semibold text-neutral-900 mb-6">
              Comprehensive Design & Construction Solutions
            </h2>
            <p className="text-neutral-600 text-lg leading-relaxed">
              From concept development to final installation, we offer end-to-end interior design 
              and construction services. Our team of experienced professionals is dedicated to 
              bringing your vision to life with exceptional quality and attention to detail.
            </p>
          </div>

          {/* Services Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {SERVICES_DATA.map((service, index) => (
              <Link
                key={service.id}
                href={`/services/${service.slug}`}
                className="group relative overflow-hidden bg-white card card-hover animate-fade-in"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                {/* Image */}
                <div className="relative h-56 overflow-hidden">
                  <Image
                    src={service.image}
                    alt={service.title}
                    fill
                    className="object-cover transition-transform duration-500 group-hover:scale-105"
                    sizes="(max-width: 768px) 100vw, 33vw"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-neutral-900/70 to-transparent" />
                </div>

                {/* Content */}
                <div className="absolute inset-0 p-6 flex flex-col justify-end">
                  <span className="text-primary-400 text-xs font-medium tracking-wider uppercase mb-2 block">
                    {service.title}
                  </span>
                  <h3 className="font-serif text-2xl font-semibold text-white mb-3">
                    {service.title}
                  </h3>
                  <p className="text-neutral-200 text-sm line-clamp-2 mb-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-100">
                    {service.shortDescription}
                  </p>
                  <div className="flex items-center text-white text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-200">
                    Explore Service
                    <ArrowRight className="ml-2 w-4 h-4 transition-transform group-hover:translate-x-1" />
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </SectionWrapper>

      {/* Process Section */}
      <SectionWrapper background="neutral">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader
            subtitle="Our Process"
            title="How We Work"
            description="Our streamlined process ensures a smooth journey from initial consultation to final delivery."
            align="center"
          />

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { step: '01', title: 'Consultation', description: 'We discuss your vision, requirements, and budget to understand your needs.' },
              { step: '02', title: 'Design', description: 'Our team creates detailed plans, 3D renderings, and material selections.' },
              { step: '03', title: 'Execution', description: 'Our skilled craftsmen bring your vision to life with precision and care.' },
              { step: '04', title: 'Delivery', description: 'Final walkthrough, quality check, and your dream space is ready.' },
            ].map((item, index) => (
              <div key={index} className="bg-white p-6 card text-center">
                <div className="w-12 h-12 bg-primary-400 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-white font-serif font-bold">{item.step}</span>
                </div>
                <h3 className="font-serif text-lg font-semibold text-neutral-900 mb-2">
                  {item.title}
                </h3>
                <p className="text-neutral-600 text-sm">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </SectionWrapper>

      {/* Why Choose Us */}
      <SectionWrapper background="white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
            <div>
              <span className="text-primary-400 text-sm font-medium tracking-wider uppercase mb-4 block">
                Why Choose Us
              </span>
              <h2 className="font-serif text-3xl md:text-4xl font-semibold text-neutral-900 mb-6">
                The Design Vision Difference
              </h2>
              <p className="text-neutral-600 mb-8 leading-relaxed">
                With over 20 years of experience and hundreds of successful projects, we have 
                established ourselves as a leader in interior design and construction. Here's 
                what sets us apart:
              </p>

              <ul className="space-y-4">
                {[
                  'Comprehensive service offerings under one roof',
                  'Award-winning design team with diverse expertise',
                  'Commitment to quality and attention to detail',
                  'Transparent pricing and project timelines',
                  'Sustainable and eco-friendly practices',
                  'Exceptional client satisfaction and referrals',
                ].map((item, index) => (
                  <li key={index} className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-primary-50 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <svg className="w-4 h-4 text-primary-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <span className="text-neutral-700">{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="relative">
              <div className="aspect-[4/5] relative overflow-hidden">
                <Image
                  src="https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?w=800&q=80"
                  alt="Our design approach"
                  fill
                  className="object-cover"
                  sizes="(max-width: 1024px) 100vw, 50vw"
                />
              </div>
            </div>
          </div>
        </div>
      </SectionWrapper>

      {/* CTA Section */}
      <SectionWrapper background="neutral">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-serif text-3xl md:text-4xl font-semibold text-neutral-900 mb-6">
            Ready to Start Your Project?
          </h2>
          <p className="text-neutral-600 mb-8 text-lg">
            Contact us today for a free consultation and let's discuss how we can bring your vision to life.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/quote"
              className="inline-flex items-center justify-center px-8 py-4 bg-primary-400 text-white font-medium hover:bg-primary-500 transition-colors"
            >
              Request a Quote
            </Link>
            <Link
              href="/contact"
              className="inline-flex items-center justify-center px-8 py-4 border-2 border-neutral-900 text-neutral-900 font-medium hover:bg-neutral-900 hover:text-white transition-colors"
            >
              Contact Us
            </Link>
          </div>
        </div>
      </SectionWrapper>
    </>
  );
}
