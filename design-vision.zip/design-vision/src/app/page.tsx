import type { Metadata } from 'next';
import HeroSection from '@/components/sections/Hero';
import SectionWrapper, { SectionHeader } from '@/components/common/SectionWrapper';
import ServicesGrid from '@/components/sections/ServicesGrid';
import PortfolioPreview from '@/components/sections/PortfolioPreview';
import AboutPreview, { Stats } from '@/components/sections/AboutPreview';
import Testimonials from '@/components/sections/Testimonials';
import TrustBadges, { ProcessStrip } from '@/components/sections/TrustBadges';
import ContactForm, { ContactInfo } from '@/components/sections/ContactForm';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';

/**
 * Homepage metadata for SEO
 */
export const metadata: Metadata = {
  title: 'Home',
  description: 'Design Vision Constructions & Interiors - Premium interior design and construction services. Transform your space with our expert team.',
};

/**
 * Homepage component - Main landing page with all key sections
 */
export default function HomePage() {
  return (
    <>
      {/* Hero Section */}
      <HeroSection
        title="Crafting Spaces That Inspire"
        subtitle="Design Vision Constructions & Interiors"
        description="We create timeless interiors and exceptional spaces that reflect your unique style. From concept to completion, our expert team transforms visions into reality."
        primaryCTA={{ text: 'Get Free Consultation', href: '/quote' }}
        secondaryCTA={{ text: 'View Portfolio', href: '/portfolio' }}
      />

      {/* Trust Badges Strip */}
      <TrustBadges />

      {/* Services Section */}
      <SectionWrapper background="white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader
            subtitle="Our Services"
            title="Comprehensive Design & Construction Solutions"
            description="From concept to completion, we offer end-to-end interior design and construction services tailored to your needs."
            align="center"
          />
          <ServicesGrid />
          <div className="text-center mt-12">
            <Link
              href="/services"
              className="inline-flex items-center text-primary-400 font-medium hover:text-primary-500 transition-colors"
            >
              View All Services
              <ArrowRight className="ml-2 w-4 h-4" />
            </Link>
          </div>
        </div>
      </SectionWrapper>

      {/* Portfolio Preview Section */}
      <SectionWrapper background="neutral">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader
            subtitle="Our Work"
            title="Featured Projects"
            description="Explore our portfolio of stunning interior design and construction projects."
            align="center"
          />
          <PortfolioPreview />
          <div className="text-center mt-12">
            <Link
              href="/portfolio"
              className="inline-flex items-center text-primary-400 font-medium hover:text-primary-500 transition-colors"
            >
              View Full Portfolio
              <ArrowRight className="ml-2 w-4 h-4" />
            </Link>
          </div>
        </div>
      </SectionWrapper>

      {/* Process Strip */}
      <ProcessStrip />

      {/* About Section */}
      <SectionWrapper background="white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <AboutPreview />
        </div>
      </SectionWrapper>

      {/* Statistics */}
      <Stats />

      {/* Testimonials Section */}
      <SectionWrapper background="neutral">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader
            subtitle="Testimonials"
            title="What Our Clients Say"
            description="Don't just take our word for it. Hear from our satisfied clients about their experience working with us."
            align="center"
          />
          <Testimonials />
          <div className="text-center mt-12">
            <Link
              href="/testimonials"
              className="inline-flex items-center text-primary-400 font-medium hover:text-primary-500 transition-colors"
            >
              Read All Reviews
              <ArrowRight className="ml-2 w-4 h-4" />
            </Link>
          </div>
        </div>
      </SectionWrapper>

      {/* CTA Banner */}
      <section className="bg-neutral-900 py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-serif text-3xl md:text-4xl font-semibold text-white mb-6">
            Ready to Transform Your Space?
          </h2>
          <p className="text-neutral-300 mb-8 text-lg">
            Let's discuss your project and bring your vision to life. Contact us today for a free consultation.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/quote"
              className="inline-flex items-center justify-center px-8 py-4 bg-primary-400 text-white font-medium hover:bg-primary-500 transition-colors"
            >
              Request a Quote
            </Link>
            <Link
              href="/contact"
              className="inline-flex items-center justify-center px-8 py-4 border-2 border-white text-white font-medium hover:bg-white hover:text-neutral-900 transition-colors"
            >
              Contact Us
            </Link>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <SectionWrapper background="white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20">
            <div>
              <SectionHeader
                subtitle="Contact Us"
                title="Get In Touch"
                description="Have a question or want to discuss your project? We'd love to hear from you."
                align="left"
              />
              <ContactInfo />
            </div>
            <div>
              <div className="bg-neutral-50 p-8">
                <h3 className="font-serif text-xl font-semibold text-neutral-900 mb-6">
                  Send Us a Message
                </h3>
                <ContactForm variant="compact" />
              </div>
            </div>
          </div>
        </div>
      </SectionWrapper>
    </>
  );
}
