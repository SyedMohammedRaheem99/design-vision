import type { Metadata } from 'next';
import Link from 'next/link';
import Image from 'next/image';
import { Star } from 'lucide-react';
import SectionWrapper from '@/components/common/SectionWrapper';
import { SectionHeader } from '@/components/common/SectionWrapper';

/**
 * Testimonials page metadata
 */
export const metadata: Metadata = {
  title: 'Testimonials',
  description: 'Read what our clients say about working with Design Vision Constructions & Interiors.',
};

/**
 * Testimonials data
 */
const TESTIMONIALS = [
  {
    id: '1',
    name: 'Sarah Mitchell',
    role: 'Homeowner',
    project: 'Penthouse Renovation',
    content: 'Working with Design Vision was an absolute pleasure. They transformed our outdated penthouse into a modern sanctuary. Their attention to detail and understanding of our lifestyle needs was exceptional. We could not be happier with the result. The team was professional, responsive, and truly listened to our vision.',
    rating: 5,
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&q=80',
  },
  {
    id: '2',
    name: 'Michael Chen',
    role: 'CEO',
    project: 'Corporate Office',
    content: 'The team at Design Vision completely reimagined our office space. Productivity has increased, and our employees love the new environment. The project was delivered on time and within budget. Highly recommend! Their expertise in commercial design really showed.',
    rating: 5,
    image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&q=80',
  },
  {
    id: '3',
    name: 'Jennifer Rodriguez',
    role: 'Restaurant Owner',
    project: 'Restaurant Interior',
    content: 'From concept to completion, Design Vision exceeded our expectations. They created a stunning restaurant interior that has become a destination in itself. Our customers consistently compliment the ambiance. The attention to acoustics and lighting was particularly impressive.',
    rating: 5,
    image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&q=80',
  },
  {
    id: '4',
    name: 'David Park',
    role: 'Homeowner',
    project: 'Kitchen Remodel',
    content: 'Our new modular kitchen is everything we dreamed of and more. The team was professional, responsive, and truly listened to our needs. The quality of workmanship is outstanding. We would highly recommend Design Vision to anyone looking to transform their space.',
    rating: 5,
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&q=80',
  },
  {
    id: '5',
    name: 'Amanda Foster',
    role: 'Interior Designer',
    project: 'Whole Home Renovation',
    content: 'As an interior designer myself, I have high standards. Design Vision impressed me with their craftsmanship and attention to detail. They brought my vision to life with precision and creativity. A truly exceptional team to work with.',
    rating: 5,
    image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&q=80',
  },
  {
    id: '6',
    name: 'Robert Kim',
    role: 'Business Owner',
    project: 'Retail Space',
    content: 'The transformation of our retail space exceeded all expectations. Sales have increased significantly since the renovation, and customers often comment on how beautiful the store looks. Design Vision delivered beyond our wildest dreams.',
    rating: 5,
    image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&q=80',
  },
];

/**
 * Testimonials page
 */
export default function TestimonialsPage() {
  return (
    <>
      {/* Page Header */}
      <section className="pt-32 pb-16 bg-neutral-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="font-serif text-4xl md:text-5xl font-semibold text-white mb-4">
            Testimonials
          </h1>
          <nav className="flex items-center space-x-2 text-sm text-neutral-400">
            <Link href="/" className="hover:text-white transition-colors">Home</Link>
            <span>/</span>
            <span className="text-primary-400">Testimonials</span>
          </nav>
        </div>
      </section>

      {/* Intro */}
      <SectionWrapper background="white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <span className="text-primary-400 text-sm font-medium tracking-wider uppercase mb-4 block">
            Client Reviews
          </span>
          <h2 className="font-serif text-3xl md:text-4xl font-semibold text-neutral-900 mb-6">
            What Our Clients Say
          </h2>
          <p className="text-neutral-600 text-lg leading-relaxed">
            Don't just take our word for it. Here's what our clients have to say about their 
            experience working with Design Vision Constructions & Interiors. Their satisfaction 
            is our greatest reward.
          </p>
        </div>
      </SectionWrapper>

      {/* Testimonials Grid */}
      <SectionWrapper background="neutral">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {TESTIMONIALS.map((testimonial, index) => (
              <div
                key={testimonial.id}
                className="bg-white p-8 card animate-fade-in"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                {/* Rating */}
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: testimonial.rating }).map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-primary-400 text-primary-400" />
                  ))}
                </div>

                {/* Content */}
                <p className="text-neutral-600 mb-6 leading-relaxed">
                  "{testimonial.content}"
                </p>

                {/* Author */}
                <div className="flex items-center space-x-4 pt-6 border-t border-neutral-100">
                  {testimonial.image && (
                    <Image
                      src={testimonial.image}
                      alt={testimonial.name}
                      width={48}
                      height={48}
                      className="rounded-full object-cover"
                    />
                  )}
                  <div>
                    <div className="font-medium text-neutral-900">{testimonial.name}</div>
                    <div className="text-sm text-neutral-500">{testimonial.role}</div>
                    <div className="text-xs text-primary-400">{testimonial.project}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </SectionWrapper>

      {/* Stats */}
      <SectionWrapper background="white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            {[
              { value: '98%', label: 'Client Satisfaction' },
              { value: '500+', label: 'Projects Completed' },
              { value: '200+', label: '5-Star Reviews' },
              { value: '95%', label: 'Would Recommend' },
            ].map((stat, index) => (
              <div
                key={index}
                className="animate-fade-in"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="text-4xl font-serif font-bold text-primary-400 mb-2">
                  {stat.value}
                </div>
                <div className="text-neutral-600 text-sm">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </SectionWrapper>

      {/* CTA */}
      <SectionWrapper background="neutral">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-serif text-3xl font-semibold text-neutral-900 mb-6">
            Ready to Become Our Next Happy Client?
          </h2>
          <p className="text-neutral-600 mb-8 text-lg">
            Let's discuss your project and see why our clients love working with us.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/quote"
              className="inline-flex items-center justify-center px-8 py-4 bg-primary-400 text-white font-medium hover:bg-primary-500 transition-colors"
            >
              Request a Quote
            </Link>
            <Link
              href="/contact"
              className="inline-flex items-center justify-center px-8 py-4 border-2 border-neutral-900 text-neutral-900 font-medium hover:bg-neutral-900 hover:text-white transition-colors"
            >
              Contact Us
            </Link>
          </div>
        </div>
      </SectionWrapper>
    </>
  );
}
