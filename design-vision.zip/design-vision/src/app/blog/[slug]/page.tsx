import type { Metadata } from 'next';
import Link from 'next/link';
import Image from 'next/image';
import { Calendar, User, Clock, ArrowLeft, Tag } from 'lucide-react';
import SectionWrapper from '@/components/common/SectionWrapper';
import { getBlogPostBySlug, getAllBlogPostSlugs, getRecentPosts } from '@/lib/data/blog';

/**
 * Generate static params for all blog posts (SSG)
 */
export async function generateStaticParams() {
  return getAllBlogPostSlugs().map((slug) => ({
    slug,
  }));
}

/**
 * Generate metadata for SEO
 */
export async function generateMetadata({ params }: { params: { slug: string } }) {
  const post = getBlogPostBySlug(params.slug);
  
  if (!post) {
    return {
      title: 'Post Not Found',
    };
  }

  return {
    title: post.title,
    description: post.excerpt,
    openGraph: {
      title: post.title,
      description: post.excerpt,
      images: [{ url: post.featuredImage }],
    },
  };
}

/**
 * Individual blog post page template
 */
export default function BlogPostPage({ params }: { params: { slug: string } }) {
  const post = getBlogPostBySlug(params.slug);
  const recentPosts = getRecentPosts(3).filter((p) => p.slug !== params.slug);

  if (!post) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="font-serif text-3xl font-semibold text-neutral-900 mb-4">
            Post Not Found
          </h1>
          <p className="text-neutral-600 mb-6">
            The article you're looking for doesn't exist.
          </p>
          <Link
            href="/blog"
            className="inline-flex items-center text-primary-400 font-medium hover:text-primary-500"
          >
            <ArrowLeft className="mr-2 w-4 h-4" />
            Back to Blog
          </Link>
        </div>
      </div>
    );
  }

  return (
    <>
      {/* Hero */}
      <section className="relative pt-32 pb-16">
        <div className="absolute inset-0 z-0 h-[50vh]">
          <Image
            src={post.featuredImage}
            alt={post.title}
            fill
            className="object-cover"
            priority
            sizes="100vw"
          />
          <div className="absolute inset-0 bg-neutral-900/70" />
        </div>
        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex items-center space-x-2 text-sm text-neutral-300 mb-6">
            <Link href="/" className="hover:text-white transition-colors">Home</Link>
            <span>/</span>
            <Link href="/blog" className="hover:text-white transition-colors">Blog</Link>
            <span>/</span>
            <span className="text-primary-400 truncate max-w-[200px]">{post.title}</span>
          </nav>
          <span className="inline-block px-3 py-1 bg-primary-400 text-white text-sm font-medium mb-4">
            {post.category}
          </span>
          <h1 className="font-serif text-3xl md:text-4xl lg:text-5xl font-semibold text-white mb-6 leading-tight">
            {post.title}
          </h1>
          <div className="flex flex-wrap items-center gap-6 text-neutral-200">
            <div className="flex items-center space-x-2">
              <User className="w-5 h-5 text-primary-400" />
              <span>{post.author}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Calendar className="w-5 h-5 text-primary-400" />
              <span>{new Date(post.publishedAt).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
              })}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Clock className="w-5 h-5 text-primary-400" />
              <span>{post.readTime}</span>
            </div>
          </div>
        </div>
      </section>

      {/* Article Content */}
      <SectionWrapper background="white">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Article Body */}
          <article className="prose prose-lg prose-neutral max-w-none">
            {/* Render the markdown-like content */}
            <div className="text-neutral-600 leading-relaxed space-y-6">
              {post.content.split('\n\n').map((paragraph, index) => {
                // Handle headers
                if (paragraph.startsWith('## ')) {
                  return (
                    <h2 key={index} className="font-serif text-2xl font-semibold text-neutral-900 mt-8 mb-4">
                      {paragraph.replace('## ', '')}
                    </h2>
                  );
                }
                // Handle list items
                if (paragraph.includes(': **')) {
                  const items = paragraph.split('\n').filter(Boolean);
                  return (
                    <ul key={index} className="space-y-2 my-4">
                      {items.map((item, i) => (
                        <li key={i} className="flex items-start space-x-2">
                          <span className="text-primary-400 mt-1">•</span>
                          <span>{item.replace(': **', '**').replace('**', '')}</span>
                        </li>
                      ))}
                    </ul>
                  );
                }
                // Regular paragraph
                return (
                  <p key={index} className="mb-4">
                    {paragraph}
                  </p>
                );
              })}
            </div>
          </article>

          {/* Tags */}
          <div className="mt-12 pt-8 border-t border-neutral-200">
            <div className="flex flex-wrap items-center gap-2">
              <Tag className="w-4 h-4 text-neutral-400" />
              {post.tags.map((tag, index) => (
                <span
                  key={index}
                  className="px-3 py-1 bg-neutral-100 text-neutral-600 text-sm"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>

          {/* Share */}
          <div className="mt-8 flex items-center justify-between">
            <Link
              href="/blog"
              className="inline-flex items-center text-primary-400 font-medium hover:text-primary-500"
            >
              <ArrowLeft className="mr-2 w-4 h-4" />
              Back to Blog
            </Link>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-neutral-500">Share:</span>
              <button className="w-8 h-8 bg-neutral-100 flex items-center justify-center text-neutral-600 hover:bg-primary-400 hover:text-white transition-colors">
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z"/>
                </svg>
              </button>
              <button className="w-8 h-8 bg-neutral-100 flex items-center justify-center text-neutral-600 hover:bg-primary-400 hover:text-white transition-colors">
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                </svg>
              </button>
            </div>
          </div>
        </div>
      </SectionWrapper>

      {/* Recent Posts */}
      {recentPosts.length > 0 && (
        <SectionWrapper background="neutral">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h3 className="font-serif text-2xl font-semibold text-neutral-900 mb-8 text-center">
              Recent Articles
            </h3>
            <div className="grid md:grid-cols-3 gap-8">
              {recentPosts.map((recentPost) => (
                <article key={recentPost.id} className="bg-white card overflow-hidden card-hover">
                  <div className="relative aspect-[16/9] overflow-hidden">
                    <Image
                      src={recentPost.featuredImage}
                      alt={recentPost.title}
                      fill
                      className="object-cover transition-transform duration-500 hover:scale-105"
                      sizes="(max-width: 768px) 100vw, 33vw"
                    />
                  </div>
                  <div className="p-6">
                    <span className="px-2 py-1 bg-primary-50 text-primary-400 text-xs font-medium mb-2 inline-block">
                      {recentPost.category}
                    </span>
                    <h4 className="font-serif text-lg font-semibold text-neutral-900 mb-2 line-clamp-2">
                      <Link href={`/blog/${recentPost.slug}`}>
                        {recentPost.title}
                      </Link>
                    </h4>
                    <p className="text-neutral-600 text-sm line-clamp-2">
                      {recentPost.excerpt}
                    </p>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </SectionWrapper>
      )}

      {/* CTA */}
      <SectionWrapper background="white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-serif text-3xl font-semibold text-neutral-900 mb-6">
            Have a Project in Mind?
          </h2>
          <p className="text-neutral-600 mb-8">
            Let's discuss how we can bring your vision to life.
          </p>
          <Link
            href="/quote"
            className="inline-flex items-center justify-center px-8 py-4 bg-primary-400 text-white font-medium hover:bg-primary-500 transition-colors"
          >
            Request a Quote
          </Link>
        </div>
      </SectionWrapper>
    </>
  );
}
