import type { Metadata } from 'next';
import Link from 'next/link';
import Image from 'next/image';
import { Calendar, User, ArrowRight, Clock } from 'lucide-react';
import SectionWrapper from '@/components/common/SectionWrapper';
import { SectionHeader } from '@/components/common/SectionWrapper';
import { BLOG_DATA, getRecentPosts } from '@/lib/data/blog';

/**
 * Blog listing page metadata
 */
export const metadata: Metadata = {
  title: 'Blog',
  description: 'Stay inspired with our latest articles on interior design, renovation tips, and industry trends.',
};

/**
 * Blog listing page
 */
export default function BlogPage() {
  const recentPosts = getRecentPosts(6);

  return (
    <>
      {/* Page Header */}
      <section className="pt-32 pb-16 bg-neutral-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="font-serif text-4xl md:text-5xl font-semibold text-white mb-4">
            Our Blog
          </h1>
          <nav className="flex items-center space-x-2 text-sm text-neutral-400">
            <Link href="/" className="hover:text-white transition-colors">Home</Link>
            <span>/</span>
            <span className="text-primary-400">Blog</span>
          </nav>
        </div>
      </section>

      {/* Featured Post */}
      <SectionWrapper background="white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {BLOG_DATA[0] && (
            <div className="grid lg:grid-cols-2 gap-8 mb-16 items-center">
              <div className="relative aspect-[4/3] overflow-hidden">
                <Image
                  src={BLOG_DATA[0].featuredImage}
                  alt={BLOG_DATA[0].title}
                  fill
                  className="object-cover hover:scale-105 transition-transform duration-500"
                  sizes="(max-width: 1024px) 100vw, 50vw"
                />
              </div>
              <div>
                <span className="inline-block px-3 py-1 bg-primary-400 text-white text-xs font-medium mb-4">
                  {BLOG_DATA[0].category}
                </span>
                <h2 className="font-serif text-3xl md:text-4xl font-semibold text-neutral-900 mb-4">
                  {BLOG_DATA[0].title}
                </h2>
                <p className="text-neutral-600 mb-6 line-clamp-3">
                  {BLOG_DATA[0].excerpt}
                </p>
                <div className="flex items-center space-x-4 text-sm text-neutral-500 mb-6">
                  <div className="flex items-center space-x-2">
                    <User className="w-4 h-4" />
                    <span>{BLOG_DATA[0].author}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Calendar className="w-4 h-4" />
                    <span>{new Date(BLOG_DATA[0].publishedAt).toLocaleDateString()}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Clock className="w-4 h-4" />
                    <span>{BLOG_DATA[0].readTime}</span>
                  </div>
                </div>
                <Link
                  href={`/blog/${BLOG_DATA[0].slug}`}
                  className="inline-flex items-center text-primary-400 font-medium hover:text-primary-500 transition-colors"
                >
                  Read Full Article
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Link>
              </div>
            </div>
          )}
        </div>
      </SectionWrapper>

      {/* Recent Posts Grid */}
      <SectionWrapper background="neutral">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader
            subtitle="Latest Articles"
            title="Recent Posts"
            description="Explore our latest articles on design trends, renovation tips, and more."
            align="center"
          />

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {BLOG_DATA.map((post, index) => (
              <article
                key={post.id}
                className="bg-white card overflow-hidden card-hover animate-fade-in"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="relative aspect-[16/9] overflow-hidden">
                  <Image
                    src={post.featuredImage}
                    alt={post.title}
                    fill
                    className="object-cover transition-transform duration-500 hover:scale-105"
                    sizes="(max-width: 768px) 100vw, 33vw"
                  />
                </div>
                <div className="p-6">
                  <div className="flex items-center space-x-2 mb-3">
                    <span className="px-2 py-1 bg-primary-50 text-primary-400 text-xs font-medium">
                      {post.category}
                    </span>
                    <span className="text-neutral-400 text-xs">{post.readTime}</span>
                  </div>
                  <h3 className="font-serif text-lg font-semibold text-neutral-900 mb-3 line-clamp-2 group-hover:text-primary-400 transition-colors">
                    <Link href={`/blog/${post.slug}`}>
                      {post.title}
                    </Link>
                  </h3>
                  <p className="text-neutral-600 text-sm mb-4 line-clamp-2">
                    {post.excerpt}
                  </p>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-neutral-500">{post.author}</span>
                    <Link
                      href={`/blog/${post.slug}`}
                      className="text-primary-400 text-sm font-medium hover:text-primary-500"
                    >
                      Read More
                    </Link>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </SectionWrapper>

      {/* Newsletter CTA */}
      <SectionWrapper background="white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-serif text-3xl md:text-4xl font-semibold text-neutral-900 mb-6">
            Stay Inspired
          </h2>
          <p className="text-neutral-600 mb-8 text-lg">
            Subscribe to our newsletter for the latest design trends, tips, and inspiration delivered to your inbox.
          </p>
          <form className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
            <input
              type="email"
              placeholder="Enter your email"
              className="flex-1 px-4 py-3 border border-neutral-300 focus:border-primary-400 outline-none transition-colors"
            />
            <button
              type="submit"
              className="px-8 py-3 bg-primary-400 text-white font-medium hover:bg-primary-500 transition-colors"
            >
              Subscribe
            </button>
          </form>
        </div>
      </SectionWrapper>
    </>
  );
}
