import type { Metadata } from 'next';
import Link from 'next/link';
import SectionWrapper from '@/components/common/SectionWrapper';
import { SectionHeader } from '@/components/common/SectionWrapper';
import QuoteForm from '@/components/sections/QuoteForm';

/**
 * Request a Quote page metadata
 */
export const metadata: Metadata = {
  title: 'Request a Quote',
  description: 'Request a free quote for your interior design or construction project. We\'ll get back to you within 24-48 hours.',
};

/**
 * Request a Quote page
 */
export default function QuotePage() {
  return (
    <>
      {/* Page Header */}
      <section className="pt-32 pb-16 bg-neutral-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="font-serif text-4xl md:text-5xl font-semibold text-white mb-4">
            Request a Quote
          </h1>
          <nav className="flex items-center space-x-2 text-sm text-neutral-400">
            <Link href="/" className="hover:text-white transition-colors">Home</Link>
            <span>/</span>
            <span className="text-primary-400">Request a Quote</span>
          </nav>
        </div>
      </section>

      {/* Quote Form */}
      <SectionWrapper background="white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <span className="text-primary-400 text-sm font-medium tracking-wider uppercase mb-4 block">
              Get Started
            </span>
            <h2 className="font-serif text-3xl md:text-4xl font-semibold text-neutral-900 mb-6">
              Tell Us About Your Project
            </h2>
            <p className="text-neutral-600 max-w-2xl mx-auto">
              Fill out the form below with details about your project, and we'll get back to you 
              within 24-48 hours with a comprehensive quote and next steps.
            </p>
          </div>

          <div className="bg-white shadow-xl p-8">
            <QuoteForm />
          </div>
        </div>
      </SectionWrapper>

      {/* What to Expect */}
      <SectionWrapper background="neutral">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader
            subtitle="What to Expect"
            title="Our Quote Process"
            description="Here's what happens after you submit your quote request."
            align="center"
          />

          <div className="grid md:grid-cols-4 gap-8">
            {[
              {
                step: '01',
                title: 'Submit Request',
                description: 'Fill out our quote form with details about your project requirements.',
              },
              {
                step: '02',
                title: 'Review & Assessment',
                description: 'Our team reviews your request and may schedule a site visit.',
              },
              {
                step: '03',
                title: 'Custom Quote',
                description: 'Receive a detailed quote with timeline and cost breakdown.',
              },
              {
                step: '04',
                title: 'Consultation',
                description: 'Discuss the quote and next steps in a personal consultation.',
              },
            ].map((item, index) => (
              <div
                key={index}
                className="text-center animate-fade-in"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="w-14 h-14 bg-primary-400 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-white font-serif font-bold">{item.step}</span>
                </div>
                <h3 className="font-serif text-lg font-semibold text-neutral-900 mb-2">
                  {item.title}
                </h3>
                <p className="text-neutral-600 text-sm">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </SectionWrapper>

      {/* Contact CTA */}
      <SectionWrapper background="white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-serif text-3xl font-semibold text-neutral-900 mb-6">
            Prefer to Talk?
          </h2>
          <p className="text-neutral-600 mb-8 text-lg">
            Give us a call and speak directly with one of our project consultants.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="tel:+15551234567"
              className="inline-flex items-center justify-center px-8 py-4 bg-primary-400 text-white font-medium hover:bg-primary-500 transition-colors"
            >
              Call Us Now
            </a>
            <Link
              href="/contact"
              className="inline-flex items-center justify-center px-8 py-4 border-2 border-neutral-900 text-neutral-900 font-medium hover:bg-neutral-900 hover:text-white transition-colors"
            >
              Contact Page
            </Link>
          </div>
        </div>
      </SectionWrapper>
    </>
  );
}
