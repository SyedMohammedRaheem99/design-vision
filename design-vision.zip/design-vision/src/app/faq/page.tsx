import type { Metadata } from 'next';
import Link from 'next/link';
import SectionWrapper from '@/components/common/SectionWrapper';
import { SectionHeader } from '@/components/common/SectionWrapper';
import Accordion from '@/components/common/Accordion';

/**
 * FAQ page metadata
 */
export const metadata: Metadata = {
  title: 'FAQ',
  description: 'Frequently asked questions about our interior design and construction services.',
};

/**
 * FAQ data
 */
const FAQ_DATA = [
  {
    id: 'faq-1',
    question: 'How long does a typical interior design project take?',
    answer: 'Project timelines vary depending on scope and complexity. A single room design might take 4-8 weeks, while a complete home renovation could take 3-6 months. During our initial consultation, we\'ll provide a detailed timeline based on your specific project requirements.',
  },
  {
    id: 'faq-2',
    question: 'Do you offer free consultations?',
    answer: 'Yes, we offer a complimentary initial consultation for projects over a certain threshold. This allows us to understand your vision and for you to learn about our process. For smaller projects, we offer a nominal consultation fee that can be applied to your project cost.',
  },
  {
    id: 'faq-3',
    question: 'What is your typical budget range?',
    answer: 'We work on projects across various budget levels, from modest room refreshes to luxury full-scale renovations. Our design fees typically start at $5,000 for room designs, while construction projects can range from $50,000 to $500,000+. We\'re happy to discuss your budget during our initial meeting.',
  },
  {
    id: 'faq-4',
    question: 'Do you work with existing contractors or only provide full-service projects?',
    answer: 'We offer flexible engagement models. We can provide design-only services if you prefer to manage construction yourself, or we can handle the entire project from concept to completion with our trusted contractor partners.',
  },
  {
    id: 'faq-5',
    question: 'How do you handle changes during the project?',
    answer: 'We understand that changes can occur during a project. We have a clear change order process that documents any modifications, associated costs, and timeline impacts. We\'ll always discuss changes with you before implementing them.',
  },
  {
    id: 'faq-6',
    question: 'What areas do you serve?',
    answer: 'We primarily serve the greater metropolitan area and surrounding suburbs. For larger commercial projects, we may consider locations within a broader region. Please contact us to confirm if we serve your location.',
  },
  {
    id: 'faq-7',
    question: 'Do you provide 3D renderings or visualizations?',
    answer: 'Yes! We use advanced 3D rendering software to help you visualize your space before construction begins. This helps ensure we\'re aligned on the design direction and allows you to make informed decisions about materials and layouts.',
  },
  {
    id: 'faq-8',
    question: 'What is your payment structure?',
    answer: 'We typically structure payments in phases aligned with project milestones. For design services, we usually require 50% upfront and 50% upon design completion. For construction projects, we establish a payment schedule with deposits and progress payments throughout the build.',
  },
  {
    id: 'faq-9',
    question: 'Are you licensed and insured?',
    answer: 'Yes, we are fully licensed and insured. Our team holds all necessary contractor licenses, and we maintain comprehensive liability insurance and workers\' compensation coverage for your protection.',
  },
  {
    id: 'faq-10',
    question: 'How do I get started?',
    answer: 'Getting started is easy! Simply fill out our quote request form or give us a call. We\'ll schedule an initial consultation to discuss your project, assess your needs, and outline the next steps.',
  },
];

/**
 * FAQ page
 */
export default function FAQPage() {
  return (
    <>
      {/* Page Header */}
      <section className="pt-32 pb-16 bg-neutral-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="font-serif text-4xl md:text-5xl font-semibold text-white mb-4">
            Frequently Asked Questions
          </h1>
          <nav className="flex items-center space-x-2 text-sm text-neutral-400">
            <Link href="/" className="hover:text-white transition-colors">Home</Link>
            <span>/</span>
            <span className="text-primary-400">FAQ</span>
          </nav>
        </div>
      </section>

      {/* FAQ Content */}
      <SectionWrapper background="white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <p className="text-neutral-600">
              Find answers to common questions about our services, process, and what to expect 
              when working with Design Vision Constructions & Interiors.
            </p>
          </div>

          <Accordion items={FAQ_DATA} />
        </div>
      </SectionWrapper>

      {/* Contact CTA */}
      <SectionWrapper background="neutral">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-serif text-3xl font-semibold text-neutral-900 mb-6">
            Still Have Questions?
          </h2>
          <p className="text-neutral-600 mb-8 text-lg">
            Can't find the answer you're looking for? Please reach out to our team.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/contact"
              className="inline-flex items-center justify-center px-8 py-4 bg-primary-400 text-white font-medium hover:bg-primary-500 transition-colors"
            >
              Contact Us
            </Link>
            <Link
              href="/quote"
              className="inline-flex items-center justify-center px-8 py-4 border-2 border-neutral-900 text-neutral-900 font-medium hover:bg-neutral-900 hover:text-white transition-colors"
            >
              Request a Quote
            </Link>
          </div>
        </div>
      </SectionWrapper>
    </>
  );
}
