import type { Metadata } from 'next';
import Link from 'next/link';
import Image from 'next/image';
import { ArrowRight, Calendar, User, Clock, MapPin } from 'lucide-react';
import SectionWrapper from '@/components/common/SectionWrapper';
import { SectionHeader } from '@/components/common/SectionWrapper';
import { getProjectBySlug } from '@/lib/data/projects';
import { PROJECTS_DATA } from '@/lib/data/projects';

/**
 * Generate static params for all project detail pages (SSG)
 */
export async function generateStaticParams() {
  return PROJECTS_DATA.map((project) => ({
    slug: project.slug,
  }));
}

/**
 * Generate metadata for SEO
 */
export async function generateMetadata({ params }: { params: { slug: string } }) {
  const project = getProjectBySlug(params.slug);
  
  if (!project) {
    return {
      title: 'Project Not Found',
    };
  }

  return {
    title: project.title,
    description: project.shortDescription,
  };
}

/**
 * Portfolio detail page template
 */
export default function ProjectDetailPage({ params }: { params: { slug: string } }) {
  const project = getProjectBySlug(params.slug);

  if (!project) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="font-serif text-3xl font-semibold text-neutral-900 mb-4">
            Project Not Found
          </h1>
          <p className="text-neutral-600 mb-6">
            The project you're looking for doesn't exist.
          </p>
          <Link
            href="/portfolio"
            className="inline-flex items-center text-primary-400 font-medium hover:text-primary-500"
          >
            Back to Portfolio
            <ArrowRight className="ml-2 w-4 h-4" />
          </Link>
        </div>
      </div>
    );
  }

  // Get related projects (same category, excluding current)
  const relatedProjects = PROJECTS_DATA
    .filter((p) => p.category === project.category && p.id !== project.id)
    .slice(0, 3);

  return (
    <>
      {/* Hero Image */}
      <section className="relative pt-32 pb-0">
        <div className="absolute inset-0 z-0 h-[60vh]">
          <Image
            src={project.images[0]}
            alt={project.title}
            fill
            className="object-cover"
            priority
            sizes="100vw"
          />
          <div className="absolute inset-0 bg-neutral-900/60" />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-32">
          <nav className="flex items-center space-x-2 text-sm text-neutral-300 mb-6">
            <Link href="/" className="hover:text-white transition-colors">Home</Link>
            <span>/</span>
            <Link href="/portfolio" className="hover:text-white transition-colors">Portfolio</Link>
            <span>/</span>
            <span className="text-primary-400">{project.title}</span>
          </nav>
          <span className="inline-block px-4 py-2 bg-primary-400 text-white text-sm font-medium mb-4">
            {project.category}
          </span>
          <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl font-semibold text-white mb-6">
            {project.title}
          </h1>
          <div className="flex flex-wrap items-center gap-6 text-neutral-200">
            <div className="flex items-center space-x-2">
              <MapPin className="w-5 h-5 text-primary-400" />
              <span>{project.location}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Calendar className="w-5 h-5 text-primary-400" />
              <span>{project.year}</span>
            </div>
            {project.area && (
              <div className="flex items-center space-x-2">
                <span className="text-primary-400">Area:</span>
                <span>{project.area}</span>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Project Details */}
      <SectionWrapper background="white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-24 relative z-20">
          <div className="bg-white shadow-xl p-8">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Main Content */}
              <div className="lg:col-span-2">
                <span className="text-primary-400 text-sm font-medium tracking-wider uppercase mb-4 block">
                  Project Overview
                </span>
                <h2 className="font-serif text-2xl md:text-3xl font-semibold text-neutral-900 mb-6">
                  About This Project
                </h2>
                <p className="text-neutral-600 mb-6 leading-relaxed">
                  {project.fullDescription}
                </p>

                {/* Challenge & Solution */}
                {project.challenge && (
                  <div className="mb-8">
                    <h3 className="font-serif text-lg font-semibold text-neutral-900 mb-3">
                      The Challenge
                    </h3>
                    <p className="text-neutral-600">{project.challenge}</p>
                  </div>
                )}

                {project.solution && (
                  <div className="mb-8">
                    <h3 className="font-serif text-lg font-semibold text-neutral-900 mb-3">
                      Our Solution
                    </h3>
                    <p className="text-neutral-600">{project.solution}</p>
                  </div>
                )}

                {/* Features */}
                <div>
                  <h3 className="font-serif text-lg font-semibold text-neutral-900 mb-4">
                    Key Features
                  </h3>
                  <ul className="grid md:grid-cols-2 gap-3">
                    {project.features.map((feature, index) => (
                      <li key={index} className="flex items-center space-x-3">
                        <div className="w-2 h-2 bg-primary-400 rounded-full" />
                        <span className="text-neutral-700">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Sidebar */}
              <div className="lg:border-l lg:border-neutral-200 lg:pl-8">
                <h3 className="font-serif text-lg font-semibold text-neutral-900 mb-6">
                  Project Details
                </h3>
                <dl className="space-y-4">
                  {project.client && (
                    <div>
                      <dt className="text-sm text-neutral-500">Client</dt>
                      <dd className="font-medium text-neutral-900">{project.client}</dd>
                    </div>
                  )}
                  <div>
                    <dt className="text-sm text-neutral-500">Category</dt>
                    <dd className="font-medium text-neutral-900">{project.category}</dd>
                  </div>
                  <div>
                    <dt className="text-sm text-neutral-500">Location</dt>
                    <dd className="font-medium text-neutral-900">{project.location}</dd>
                  </div>
                  <div>
                    <dt className="text-sm text-neutral-500">Year</dt>
                    <dd className="font-medium text-neutral-900">{project.year}</dd>
                  </div>
                  {project.area && (
                    <div>
                      <dt className="text-sm text-neutral-500">Area</dt>
                      <dd className="font-medium text-neutral-900">{project.area}</dd>
                    </div>
                  )}
                </dl>

                <div className="mt-8 pt-8 border-t border-neutral-200">
                  <Link
                    href="/quote"
                    className="inline-flex items-center justify-center w-full px-6 py-4 bg-primary-400 text-white font-medium hover:bg-primary-500 transition-colors"
                  >
                    Start Your Project
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </SectionWrapper>

      {/* Image Gallery */}
      <SectionWrapper background="neutral">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader
            subtitle="Gallery"
            title="Project Gallery"
            description="A visual journey through this stunning transformation."
            align="center"
          />

          <div className="grid md:grid-cols-2 gap-6">
            {project.images.map((image, index) => (
              <div
                key={index}
                className={`relative overflow-hidden ${
                  index === 0 ? 'md:col-span-2 aspect-[2/1]' : 'aspect-[4/3]'
                }`}
              >
                <Image
                  src={image}
                  alt={`${project.title} - Image ${index + 1}`}
                  fill
                  className="object-cover hover:scale-105 transition-transform duration-500"
                  sizes={index === 0 ? '(max-width: 768px) 100vw, 66vw' : '(max-width: 768px) 100vw, 33vw'}
                />
              </div>
            ))}
          </div>
        </div>
      </SectionWrapper>

      {/* Related Projects */}
      {relatedProjects.length > 0 && (
        <SectionWrapper background="white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <SectionHeader
              subtitle="More Projects"
              title="Related Projects"
              description="Explore more of our recent work."
              align="center"
            />

            <div className="grid md:grid-cols-3 gap-8">
              {relatedProjects.map((relatedProject) => (
                <Link
                  key={relatedProject.id}
                  href={`/portfolio/${relatedProject.slug}`}
                  className="group card overflow-hidden card-hover"
                >
                  <div className="relative aspect-[16/10] overflow-hidden">
                    <Image
                      src={relatedProject.thumbnail}
                      alt={relatedProject.title}
                      fill
                      className="object-cover transition-transform duration-500 group-hover:scale-105"
                      sizes="(max-width: 768px) 100vw, 33vw"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-neutral-900/70 to-transparent" />
                    <div className="absolute bottom-4 left-4 right-4">
                      <span className="text-primary-400 text-xs font-medium uppercase mb-1 block">
                        {relatedProject.category}
                      </span>
                      <h3 className="font-serif text-lg font-semibold text-white">
                        {relatedProject.title}
                      </h3>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </SectionWrapper>
      )}

      {/* CTA Section */}
      <SectionWrapper background="neutral">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-serif text-3xl md:text-4xl font-semibold text-neutral-900 mb-6">
            Ready to Create Your Dream Space?
          </h2>
          <p className="text-neutral-600 mb-8 text-lg">
            Let's discuss your project and bring your vision to life.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/quote"
              className="inline-flex items-center justify-center px-8 py-4 bg-primary-400 text-white font-medium hover:bg-primary-500 transition-colors"
            >
              Request a Quote
            </Link>
            <Link
              href="/contact"
              className="inline-flex items-center justify-center px-8 py-4 border-2 border-neutral-900 text-neutral-900 font-medium hover:bg-neutral-900 hover:text-white transition-colors"
            >
              Contact Us
            </Link>
          </div>
        </div>
      </SectionWrapper>
    </>
  );
}
