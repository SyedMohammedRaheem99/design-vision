import type { Metadata } from 'next';
import Link from 'next/link';
import Image from 'next/image';
import { ArrowRight } from 'lucide-react';
import SectionWrapper from '@/components/common/SectionWrapper';
import { SectionHeader } from '@/components/common/SectionWrapper';
import { ProjectCard } from '@/components/sections/PortfolioPreview';
import { PROJECTS_DATA } from '@/lib/data/projects';

/**
 * Portfolio listing page metadata
 */
export const metadata: Metadata = {
  title: 'Portfolio',
  description: 'Explore our portfolio of interior design and construction projects. From luxury homes to commercial spaces, see our work.',
};

/**
 * Get unique categories from projects
 */
const CATEGORIES = ['All', ...new Set(PROJECTS_DATA.map((p) => p.category))];

/**
 * Portfolio listing page
 */
export default function PortfolioPage() {
  return (
    <>
      {/* Page Header */}
      <section className="pt-32 pb-16 bg-neutral-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="font-serif text-4xl md:text-5xl font-semibold text-white mb-4">
            Our Portfolio
          </h1>
          <nav className="flex items-center space-x-2 text-sm text-neutral-400">
            <Link href="/" className="hover:text-white transition-colors">Home</Link>
            <span>/</span>
            <span className="text-primary-400">Portfolio</span>
          </nav>
        </div>
      </section>

      {/* Portfolio Grid */}
      <SectionWrapper background="white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="text-primary-400 text-sm font-medium tracking-wider uppercase mb-4 block">
              Our Work
            </span>
            <h2 className="font-serif text-3xl md:text-4xl font-semibold text-neutral-900 mb-6">
              Featured Projects
            </h2>
            <p className="text-neutral-600 max-w-3xl mx-auto">
              Explore our portfolio of stunning interior design and construction projects. 
              Each project reflects our commitment to quality, innovation, and client satisfaction.
            </p>
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {CATEGORIES.map((category) => (
              <button
                key={category}
                className={`px-6 py-2 text-sm font-medium transition-colors ${
                  category === 'All'
                    ? 'bg-primary-400 text-white'
                    : 'border border-neutral-300 text-neutral-700 hover:border-primary-400 hover:text-primary-400'
                }`}
              >
                {category}
              </button>
            ))}
          </div>

          {/* Projects Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {PROJECTS_DATA.map((project, index) => (
              <div
                key={project.id}
                className="animate-fade-in"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <ProjectCard project={project} />
              </div>
            ))}
          </div>
        </div>
      </SectionWrapper>

      {/* Stats Section */}
      <SectionWrapper background="neutral">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            {[
              { value: '500+', label: 'Projects Completed' },
              { value: '20+', label: 'Years Experience' },
              { value: '98%', label: 'Client Satisfaction' },
              { value: '50+', label: 'Design Awards' },
            ].map((stat, index) => (
              <div
                key={index}
                className="animate-fade-in"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="text-4xl font-serif font-bold text-primary-400 mb-2">
                  {stat.value}
                </div>
                <div className="text-neutral-600 text-sm">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </SectionWrapper>

      {/* CTA Section */}
      <SectionWrapper background="white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-serif text-3xl md:text-4xl font-semibold text-neutral-900 mb-6">
            Have a Project in Mind?
          </h2>
          <p className="text-neutral-600 mb-8 text-lg">
            We'd love to hear about your project and discuss how we can bring your vision to life.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/quote"
              className="inline-flex items-center justify-center px-8 py-4 bg-primary-400 text-white font-medium hover:bg-primary-500 transition-colors"
            >
              Start Your Project
            </Link>
            <Link
              href="/contact"
              className="inline-flex items-center justify-center px-8 py-4 border-2 border-neutral-900 text-neutral-900 font-medium hover:bg-neutral-900 hover:text-white transition-colors"
            >
              Contact Us
            </Link>
          </div>
        </div>
      </SectionWrapper>
    </>
  );
}
