import type { Metadata } from 'next';
import Link from 'next/link';
import SectionWrapper from '@/components/common/SectionWrapper';
import { SectionHeader } from '@/components/common/SectionWrapper';
import ContactForm, { ContactInfo } from '@/components/sections/ContactForm';
import { MapPin, Phone, Mail, Clock } from 'lucide-react';

/**
 * Contact page metadata
 */
export const metadata: Metadata = {
  title: 'Contact Us',
  description: 'Get in touch with Design Vision Constructions & Interiors. We\'re here to answer your questions and discuss your project.',
};

/**
 * Contact page
 */
export default function ContactPage() {
  return (
    <>
      {/* Page Header */}
      <section className="pt-32 pb-16 bg-neutral-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="font-serif text-4xl md:text-5xl font-semibold text-white mb-4">
            Contact Us
          </h1>
          <nav className="flex items-center space-x-2 text-sm text-neutral-400">
            <Link href="/" className="hover:text-white transition-colors">Home</Link>
            <span>/</span>
            <span className="text-primary-400">Contact</span>
          </nav>
        </div>
      </section>

      {/* Contact Info & Form */}
      <SectionWrapper background="white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20">
            {/* Contact Information */}
            <div>
              <SectionHeader
                subtitle="Get In Touch"
                title="Let's Start a Conversation"
                description="Have a question or want to discuss your project? We'd love to hear from you. Reach out to us through any of the channels below."
                align="left"
              />

              <div className="space-y-6 mt-8">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-primary-50 flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-5 h-5 text-primary-400" />
                  </div>
                  <div>
                    <h4 className="font-medium text-neutral-900 mb-1">Visit Us</h4>
                    <p className="text-neutral-600">
                      1234 Design Avenue, Suite 100<br />
                      New York, NY 10001
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-primary-50 flex items-center justify-center flex-shrink-0">
                    <Phone className="w-5 h-5 text-primary-400" />
                  </div>
                  <div>
                    <h4 className="font-medium text-neutral-900 mb-1">Call Us</h4>
                    <p className="text-neutral-600">
                      <a href="tel:+15551234567" className="hover:text-primary-400 transition-colors">
                        +1 (555) 123-4567
                      </a>
                    </p>
                    <p className="text-sm text-neutral-500">Mon - Fri: 9AM - 6PM</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-primary-50 flex items-center justify-center flex-shrink-0">
                    <Mail className="w-5 h-5 text-primary-400" />
                  </div>
                  <div>
                    <h4 className="font-medium text-neutral-900 mb-1">Email Us</h4>
                    <p className="text-neutral-600">
                      <a href="mailto:info@designvision.com" className="hover:text-primary-400 transition-colors">
                        info@designvision.com
                      </a>
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-primary-50 flex items-center justify-center flex-shrink-0">
                    <Clock className="w-5 h-5 text-primary-400" />
                  </div>
                  <div>
                    <h4 className="font-medium text-neutral-900 mb-1">Business Hours</h4>
                    <p className="text-neutral-600 whitespace-pre-line">
                      Monday - Friday: 9AM - 6PM
                      Saturday: 10AM - 4PM
                      Sunday: Closed
                    </p>
                  </div>
                </div>
              </div>

              {/* Map Placeholder */}
              <div className="mt-8 bg-neutral-100 h-64 flex items-center justify-center">
                <p className="text-neutral-500">Map integration placeholder</p>
              </div>
            </div>

            {/* Contact Form */}
            <div className="bg-neutral-50 p-8">
              <h3 className="font-serif text-2xl font-semibold text-neutral-900 mb-6">
                Send Us a Message
              </h3>
              <ContactForm />
            </div>
          </div>
        </div>
      </SectionWrapper>

      {/* FAQ CTA */}
      <SectionWrapper background="neutral">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-serif text-3xl font-semibold text-neutral-900 mb-6">
            Have Questions?
          </h2>
          <p className="text-neutral-600 mb-8 text-lg">
            Check our Frequently Asked Questions page for quick answers to common questions.
          </p>
          <Link
            href="/faq"
            className="inline-flex items-center justify-center px-8 py-4 border-2 border-neutral-900 text-neutral-900 font-medium hover:bg-neutral-900 hover:text-white transition-colors"
          >
            View FAQ
          </Link>
        </div>
      </SectionWrapper>
    </>
  );
}
