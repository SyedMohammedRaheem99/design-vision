import type { Metadata } from 'next';
import Link from 'next/link';
import SectionWrapper from '@/components/common/SectionWrapper';

/**
 * Terms & Conditions page metadata
 */
export const metadata: Metadata = {
  title: 'Terms & Conditions',
  description: 'Terms and conditions governing the use of Design Vision Constructions & Interiors website and services.',
};

/**
 * Terms & Conditions page
 */
export default function TermsPage() {
  return (
    <>
      {/* Page Header */}
      <section className="pt-32 pb-16 bg-neutral-900">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="font-serif text-4xl md:text-5xl font-semibold text-white mb-4">
            Terms & Conditions
          </h1>
          <nav className="flex items-center space-x-2 text-sm text-neutral-400">
            <Link href="/" className="hover:text-white transition-colors">Home</Link>
            <span>/</span>
            <span className="text-primary-400">Terms & Conditions</span>
          </nav>
        </div>
      </section>

      {/* Content */}
      <SectionWrapper background="white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="prose prose-neutral max-w-none">
            <p className="text-neutral-600 mb-8">
              Last updated: January 2024
            </p>

            <section className="mb-12">
              <h2 className="font-serif text-2xl font-semibold text-neutral-900 mb-4">
                1. Acceptance of Terms
              </h2>
              <p className="text-neutral-600 leading-relaxed">
                By accessing and using this website, you accept and agree to be bound by the terms 
                and provisions of this agreement. If you do not agree to abide by these terms, 
                please do not use this website.
              </p>
            </section>

            <section className="mb-12">
              <h2 className="font-serif text-2xl font-semibold text-neutral-900 mb-4">
                2. Use of Website
              </h2>
              <p className="text-neutral-600 leading-relaxed mb-4">
                This website and its contents are intended for informational purposes only. You 
                may use this website solely for lawful purposes and in accordance with these Terms 
                of Service.
              </p>
              <p className="text-neutral-600 leading-relaxed">
                You agree not to use this website in any manner that could damage, disable, overburden, 
                or impair the website or interfere with any other party's use of the website.
              </p>
            </section>

            <section className="mb-12">
              <h2 className="font-serif text-2xl font-semibold text-neutral-900 mb-4">
                3. Intellectual Property
              </h2>
              <p className="text-neutral-600 leading-relaxed">
                All content on this website, including but not limited to text, graphics, logos, 
                images, audio clips, and software, is the property of Design Vision Constructions 
                & Interiors or its content suppliers and is protected by copyright and other 
                intellectual property laws.
              </p>
            </section>

            <section className="mb-12">
              <h2 className="font-serif text-2xl font-semibold text-neutral-900 mb-4">
                4. Limitation of Liability
              </h2>
              <p className="text-neutral-600 leading-relaxed">
                Design Vision Constructions & Interiors shall not be liable for any damages arising 
                from the use of this website or any linked websites. This includes direct, indirect, 
                incidental, consequential, and punitive damages.
              </p>
            </section>

            <section className="mb-12">
              <h2 className="font-serif text-2xl font-semibold text-neutral-900 mb-4">
                5. Quotes and Proposals
              </h2>
              <p className="text-neutral-600 leading-relaxed mb-4">
                All quotes and proposals provided by Design Vision Constructions & Interiors are 
                valid for a period of 30 days from the date of issuance unless otherwise specified.
              </p>
              <p className="text-neutral-600 leading-relaxed">
                Prices quoted are subject to change based on final selections, scope changes, or 
                circumstances beyond our control at the time of project execution.
              </p>
            </section>

            <section className="mb-12">
              <h2 className="font-serif text-2xl font-semibold text-neutral-900 mb-4">
                6. Project Terms
              </h2>
              <p className="text-neutral-600 leading-relaxed mb-4">
                For design and construction services, separate agreements will be provided that 
                outline specific terms, payment schedules, timelines, and warranties applicable 
                to your project.
              </p>
              <p className="text-neutral-600 leading-relaxed">
                A deposit is required to secure project scheduling and commencement. All deposits 
                are non-refundable unless otherwise agreed in writing.
              </p>
            </section>

            <section className="mb-12">
              <h2 className="font-serif text-2xl font-semibold text-neutral-900 mb-4">
                7. Privacy Policy
              </h2>
              <p className="text-neutral-600 leading-relaxed">
                Your use of this website is also governed by our Privacy Policy, which is 
                incorporated into these Terms of Service by reference.
              </p>
            </section>

            <section className="mb-12">
              <h2 className="font-serif text-2xl font-semibold text-neutral-900 mb-4">
                8. Changes to Terms
              </h2>
              <p className="text-neutral-600 leading-relaxed">
                Design Vision Constructions & Interiors reserves the right to modify these Terms 
                of Service at any time. Continued use of the website after any such changes 
                constitutes acceptance of the new Terms of Service.
              </p>
            </section>

            <section className="mb-12">
              <h2 className="font-serif text-2xl font-semibold text-neutral-900 mb-4">
                9. Contact Information
              </h2>
              <p className="text-neutral-600 leading-relaxed">
                If you have any questions about these Terms of Service, please contact us at:
              </p>
              <div className="mt-4 p-4 bg-neutral-50">
                <p className="text-neutral-700">
                  <strong>Design Vision Constructions & Interiors</strong><br />
                  1234 Design Avenue, Suite 100<br />
                  New York, NY 10001<br />
                  Email: info@designvision.com<br />
                  Phone: +1 (555) 123-4567
                </p>
              </div>
            </section>
          </div>
        </div>
      </SectionWrapper>
    </>
  );
}
