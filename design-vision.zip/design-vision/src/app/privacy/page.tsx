import type { Metadata } from 'next';
import Link from 'next/link';
import SectionWrapper from '@/components/common/SectionWrapper';

/**
 * Privacy Policy page metadata
 */
export const metadata: Metadata = {
  title: 'Privacy Policy',
  description: 'Privacy policy governing the collection and use of your personal information.',
};

/**
 * Privacy Policy page
 */
export default function PrivacyPage() {
  return (
    <>
      {/* Page Header */}
      <section className="pt-32 pb-16 bg-neutral-900">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="font-serif text-4xl md:text-5xl font-semibold text-white mb-4">
            Privacy Policy
          </h1>
          <nav className="flex items-center space-x-2 text-sm text-neutral-400">
            <Link href="/" className="hover:text-white transition-colors">Home</Link>
            <span>/</span>
            <span className="text-primary-400">Privacy Policy</span>
          </nav>
        </div>
      </section>

      {/* Content */}
      <SectionWrapper background="white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="prose prose-neutral max-w-none">
            <p className="text-neutral-600 mb-8">
              Last updated: January 2024
            </p>

            <section className="mb-12">
              <h2 className="font-serif text-2xl font-semibold text-neutral-900 mb-4">
                1. Introduction
              </h2>
              <p className="text-neutral-600 leading-relaxed">
                Design Vision Constructions & Interiors ("we," "our," or "us") is committed to 
                protecting your privacy. This Privacy Policy explains how we collect, use, disclose, 
                and safeguard your information when you visit our website or use our services.
              </p>
            </section>

            <section className="mb-12">
              <h2 className="font-serif text-2xl font-semibold text-neutral-900 mb-4">
                2. Information We Collect
              </h2>
              <p className="text-neutral-600 leading-relaxed mb-4">
                We may collect personal information that you voluntarily provide to us when you:
              </p>
              <ul className="list-disc pl-6 space-y-2 text-neutral-600">
                <li>Fill out contact or quote request forms</li>
                <li>Subscribe to our newsletter</li>
                <li>Request information about our services</li>
                <li>Communicate with us via email or phone</li>
              </ul>
              <p className="text-neutral-600 leading-relaxed mt-4">
                This information may include your name, email address, phone number, project details, 
                and any other information you choose to provide.
              </p>
            </section>

            <section className="mb-12">
              <h2 className="font-serif text-2xl font-semibold text-neutral-900 mb-4">
                3. How We Use Your Information
              </h2>
              <p className="text-neutral-600 leading-relaxed mb-4">
                We use the information we collect to:
              </p>
              <ul className="list-disc pl-6 space-y-2 text-neutral-600">
                <li>Respond to your inquiries and provide requested services</li>
                <li>Send you quotes, project updates, and relevant information</li>
                <li>Improve our website and services</li>
                <li>Comply with legal obligations</li>
                <li>Send marketing communications (with your consent)</li>
              </ul>
            </section>

            <section className="mb-12">
              <h2 className="font-serif text-2xl font-semibold text-neutral-900 mb-4">
                4. Information Sharing and Disclosure
              </h2>
              <p className="text-neutral-600 leading-relaxed mb-4">
                We do not sell, trade, or otherwise transfer your personally identifiable information 
                to outside parties except in the following circumstances:
              </p>
              <ul className="list-disc pl-6 space-y-2 text-neutral-600">
                <li>With trusted service providers who assist in our operations</li>
                <li>To comply with legal requirements or respond to lawful requests</li>
                <li>To protect our rights, privacy, safety, or property</li>
                <li>In connection with a merger, acquisition, or sale of assets</li>
              </ul>
            </section>

            <section className="mb-12">
              <h2 className="font-serif text-2xl font-semibold text-neutral-900 mb-4">
                5. Data Security
              </h2>
              <p className="text-neutral-600 leading-relaxed">
                We implement appropriate security measures to protect your personal information 
                against unauthorized access, alteration, disclosure, or destruction. However, no 
                method of transmission over the Internet is 100% secure, and we cannot guarantee 
                absolute security.
              </p>
            </section>

            <section className="mb-12">
              <h2 className="font-serif text-2xl font-semibold text-neutral-900 mb-4">
                6. Cookies and Tracking Technologies
              </h2>
              <p className="text-neutral-600 leading-relaxed mb-4">
                Our website may use cookies and similar tracking technologies to enhance your 
                experience. You can set your browser to refuse all cookies or to indicate when 
                a cookie is being sent.
              </p>
              <p className="text-neutral-600 leading-relaxed">
                Cookies help us understand how visitors use our website and improve your experience.
              </p>
            </section>

            <section className="mb-12">
              <h2 className="font-serif text-2xl font-semibold text-neutral-900 mb-4">
                7. Third-Party Links
              </h2>
              <p className="text-neutral-600 leading-relaxed">
                Our website may contain links to third-party websites. We are not responsible for 
                the privacy practices or content of these third-party sites. We encourage you to 
                review their privacy policies.
              </p>
            </section>

            <section className="mb-12">
              <h2 className="font-serif text-2xl font-semibold text-neutral-900 mb-4">
                8. Your Rights
              </h2>
              <p className="text-neutral-600 leading-relaxed mb-4">
                You have the right to:
              </p>
              <ul className="list-disc pl-6 space-y-2 text-neutral-600">
                <li>Request access to your personal information</li>
                <li>Request correction of inaccurate information</li>
                <li>Request deletion of your information</li>
                <li>Opt-out of marketing communications</li>
                <li>Lodge a complaint with a supervisory authority</li>
              </ul>
            </section>

            <section className="mb-12">
              <h2 className="font-serif text-2xl font-semibold text-neutral-900 mb-4">
                9. Children's Privacy
              </h2>
              <p className="text-neutral-600 leading-relaxed">
                Our website is not intended for children under the age of 13. We do not knowingly 
                collect personal information from children under 13.
              </p>
            </section>

            <section className="mb-12">
              <h2 className="font-serif text-2xl font-semibold text-neutral-900 mb-4">
                10. Changes to This Policy
              </h2>
              <p className="text-neutral-600 leading-relaxed">
                We may update this Privacy Policy from time to time. We will notify you of any 
                changes by posting the new Privacy Policy on this page and updating the "Last 
                updated" date.
              </p>
            </section>

            <section className="mb-12">
              <h2 className="font-serif text-2xl font-semibold text-neutral-900 mb-4">
                11. Contact Us
              </h2>
              <p className="text-neutral-600 leading-relaxed">
                If you have questions about this Privacy Policy, please contact us at:
              </p>
              <div className="mt-4 p-4 bg-neutral-50">
                <p className="text-neutral-700">
                  <strong>Design Vision Constructions & Interiors</strong><br />
                  1234 Design Avenue, Suite 100<br />
                  New York, NY 10001<br />
                  Email: info@designvision.com<br />
                  Phone: +1 (555) 123-4567
                </p>
              </div>
            </section>
          </div>
        </div>
      </SectionWrapper>
    </>
  );
}
